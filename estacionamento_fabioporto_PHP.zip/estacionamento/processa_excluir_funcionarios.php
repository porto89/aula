<?php
session_start();
include_once('assets/cabecalho.php');
include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();


$id_funcionario = mysqli_real_escape_string($conn, $_GET['id_funcionario']);

$altera_funcionario = "DELETE FROM funcionarios WHERE id_funcionario='$id_funcionario'";
$resposta = mysqli_query($conn, $altera_funcionario);

if ($resposta) {
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-warning'>
      <p>FUNCIONARIO EXCLUÍDO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: funcionario.php');
} else {

    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-warning'>
      <p>NÃO FOI POSSÍVEL EXCLUIR O FUNCIONARIO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: funcionario.php');

}

?>