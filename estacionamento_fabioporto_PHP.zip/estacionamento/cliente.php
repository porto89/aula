<?php
session_start();
include_once('static/cabecalho.php');

include('config/conexao.php');
include_once("config/seguranca.php");
seguranca_adm();
$consulta = "SELECT * FROM clientes ";
$resultado = mysqli_query($conn, $consulta);

if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
  $page_no = $_GET['page_no'];
} else {
  $page_no = 1;
}

$total_records_per_page = 10;

$offset = ($page_no - 1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";

$result_count = mysqli_query(
  $conn,
  "SELECT COUNT(*) As total_records FROM `clientes`"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
?>

<style>
  .table__wrapper {
    overflow-x: auto;
  }
</style>

<?php include_once('static/nav.php'); ?>

<section class="section has-background-link-light">
  <div class="container" class="modal fade" id="cadCliente" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <?php
    if (isset($_SESSION['error'])) {
      echo $_SESSION['error'];
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
      echo $_SESSION['success'];
      unset($_SESSION['success']);
    }
    ?>
    <div class="box" style="width: 1048px; max-width: 100%">
      <article class="panel is-info">
        <p class="panel-heading">Cadastro de Cliente</p>

        <div class="box">
          <form method="POST" action="processa_cadastro_clientes.php" enctype="multipart/form-data" id="form_contato">
            <div class="field-group is-bordered is-horizontal">
              <div class="field">
                <label class="label">Nome</label>
                <div class="control" style="width: 350px">
                  <input class="input" type="text" name="nome" id="nome" required placeholder="Nome" />
                </div>

              </div>

              <div class="field">
                <label class="label">Data de nascimento</label>
                <div class="control">
                  <input class="input" type="text" name="nascimento" id="nascimento" required
                    placeholder="##/##/####" />
                </div>

              </div>
              <div class="field">
                <label class="label">Email</label>
                <div class="control">
                  <input class="input" type="text" name="email" id="email" required placeholder="exemplo@servidor.com" />
                </div>

              </div>
            </div>

            <div class="field-group is-horizontal">
              <div class="field">
                <div class="control">
                <label class="label">CPF/CNJP</label>
                  <div class="control" style="width: 180px">
                    <input class="input" type="text" name="cpf_cnjp" id="cpf_cnjp" required />
                  </div>
                </div>

              </div>
            </div>

            <div class="field-group is-horizontal">
              <div class="field">
                <label class="label">RG</label>
                <div class="control" style="width: 180px">
                  <input class="input" type="text" name="rg" id="rg" required placeholder="RG" />
                </div>

              </div>
            </div>

            <div class="field">
              <label class="label">CEP</label>
              <div class="control">
                <input class="input" id="recipient-cep" type="text" name="cep" id="cep" required maxlength="50"
                  onblur="pesquisacep(this.value);">
              </div>

            </div>

            <div class="field-group is-horizontal">
              <div class="field">
                <label class="label">Rua</label>
                <div class="control">
                  <input class="input" type="text" name="rua" id="rua" required placeholder="rua" />
                </div>

              </div>

              <div class="field">
                <label class="label">Numero</label>
                <div class="control">
                  <input class="input" type="text" name="numero" id="numero" required placeholder="numero" />
                </div>

              </div>

              <div class="field">
                <label class="label">Complemento</label>
                <div class="control">
                  <input class="input" type="text" name="complemento" id="complemento" required
                    placeholder="Casa ou Apartamento" />
                </div>

              </div>
              <div class="field">
                <label class="label">Bairro</label>
                <div class="control">
                  <input class="input" type="text" name="bairro" id="bairro" required placeholder="bairro" />
                </div>

              </div>
              <div class="field">
                <label class="label">Cidade</label>
                <div class="control">
                  <input class="input" type="text" name="cidade" id="cidade" required placeholder="Cidade" />
                </div>

              </div>
              <div class="field">
                <label class="label">Estado</label>
                <div class="control">
                  <input class="input" type="text" name="estado" id="estado" required placeholder="estado" />
                </div>

              </div>
            </div>
            <div class="field-group is-horizontal">
              <div class="field">
                <label class="label">Telefone</label>
                <div class="control">
                  <input class="input" type="text" name="telefone" id="telefone" required
                    onkeypress="mask(this, telefone);" onblur="mask(this, telefone);" placeholder="telefone" />
                </div>

              </div>

              <div class="field">
                <label class="label">Residencial</label>
                <div class="control">
                  <input class="input" type="text" name="residencial" id="residencial" 
                    onkeypress="mask(this, residencial);" onblur="mask(this, residencial);" placeholder="residencial" />
                </div>

              </div>

              <div class="field">
                <label class="label">Celular</label>
                <div class="control">
                  <input class="input" type="text" name="celular" id="celular" required
                    onkeypress="mask(this, celular);" onblur="mask(this, celular);" placeholder="" />
                </div>

              </div>
              <div class="field">
                <label class="label">Recado</label>
                <div class="control">
                  <input class="input" type="text" name="recado" id="recado"  onkeypress="mask(this, recado);"
                    onblur="mask(this, recado);" placeholder="recado" />
                </div>

              </div>
              <div class="field">
                <label class="label">Comercial</label>
                <div class="control">
                  <input class="input" type="text" name="comercial" id="comercial" 
                    onkeypress="mask(this, comercial);" onblur="mask(this, comercial);" placeholder="comercial" />
                </div>

              </div>
            </div>
            <hr />

            <div class="field-group is-horizontal">
              <div class="field">
                <label class="label">Pagamento dia</label>
                <div class="control" style="width: 120px">
                  <input class="input" type="text" name="pagamento_dia" id="pagamento_dia" required />
                </div>

              </div>
            </div>

            <div class="field is-grouped">
              <div class="control">
                <button type="submit" class="button is-link is-light">Adicionar</button>
              </div>
              <div class="control">
                <button type="reset" class="button is-link is-light">Limpar</button>
              </div>
            </div>
          </form>
        </div>

        <hr />
        <article class="panel is-info">
          <p class="panel-heading">Listagen de Clientes</p>
          <div class="box">

            <div class="table__wrapper">

              <div class="control is-expanded">
                <label class="label p-2 mt-2">Nome do cliente: </label>
                <input class="input" type="text" name="pesquisa_cliente" id="pesquisa_cliente" value=""
                  placeholder="ex: fabio porto" required autofocus>

              </div>

              <br>

              <table
                class="table is-table is-bordered is-striped is-narrow is-hoverable is-fullwidth resultado_cliente">

                <thead>
                  <tr class="bg-dark text text-white">
                    <th scope="col">ID</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Data de nascimento</th>
                    <th scope="col">Email</th>
                    <th scope="col">CPF/CNPJ</th>
                    <th scope="col">RG</th>
                    <th scope="col">CEP</th>
                    <th scope="col">Rua</th>
                    <th scope="col">Numero</th>
                    <th scope="col">Complemento</th>
                    <th scope="col">Bairro</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Telefone</th>
                    <th scope="col">Residencial</th>
                    <th scope="col">Celular</th>
                    <th scope="col">Recado</th>
                    <th scope="col">Comercial</th>
                    <th scope="col">Pagamento dia</th>
                    <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
                  </tr>
                </thead>
                <tbody>



                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT * FROM `clientes` LIMIT $offset, $total_records_per_page"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) {
                    $id_cliente = $linha['id_cliente'];
                    $nome = $linha['nome'];
                    $nascimento = $linha['nascimento'];
                    $nascimento = date('d/m/Y', strtotime($nascimento));
                    $email = $linha['email'];
                    $cpf_cnjp = $linha['cpf_cnjp'];
                    $rg = $linha['rg'];
                    $cep = $linha['cep'];
                    $rua = $linha['rua'];
                    $numero = $linha['numero'];
                    $complemento = $linha['complemento'];
                    $bairro = $linha['bairro'];
                    $cidade = $linha['cidade'];
                    $estado = $linha['estado'];
                    $telefone = $linha['telefone'];
                    $residencial = $linha['residencial'];
                    $celular = $linha['celular'];
                    $recado = $linha['recado'];
                    $comercial = $linha['comercial'];
                    $pagamento_dia = $linha['pagamento_dia'];
                    $pagamento_dia = date('d/m/Y', strtotime($pagamento_dia));

                    $endereco = $rua . ", " . $numero . " - " . $bairro . "-" . $cidade . "/" . $estado;

                    ?>
                    <td>
                      <?= $linha['id_cliente'] ?>
                    </td>
                    <td>
                      <?= $linha['nome'] ?>
                    </td>
                    <td>
                      <?= $linha['nascimento'] ?>
                    </td>
                    <td>
                      <?= $linha['email'] ?>
                    </td>
                    <td>
                      <?= $linha['cpf_cnjp'] ?>
                    </td>
                    <td>
                      <?= $linha['rg'] ?>
                    </td>
                    <td>
                      <?= $linha['cep'] ?>
                    </td>
                    <td>
                      <?= $linha['rua'] ?>
                    </td>
                    <td>
                      <?= $linha['numero'] ?>
                    </td>
                    <td>
                      <?= $linha['complemento'] ?>
                    </td>
                    <td>
                      <?= $linha['bairro'] ?>
                    </td>
                    <td>
                      <?= $linha['cidade'] ?>
                    </td>
                    <td>
                      <?= $linha['estado'] ?>
                    </td>
                    <td>
                      <?= $linha['telefone'] ?>
                    </td>
                    <td>
                      <?= $linha['residencial'] ?>
                    </td>
                    <td>
                      <?= $linha['celular'] ?>
                    </td>
                    <td>
                      <?= $linha['recado'] ?>
                    </td>
                    <td>
                      <?= $linha['comercial'] ?>
                    </td>
                    <td>
                      <?= $linha['pagamento_dia'] ?>
                    </td>

                    </td>
                    <td class="text text-center">


                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#visualizarCliente" data-whatever="<?php echo $linha['id_cliente']; ?>"
                        data-whatevernome="<?php echo ucwords(strtolower($linha['nome'])); ?>"
                        data-whatevernascimento="<?php echo $nascimento; ?>"
                        data-whateveremail="<?php echo $linha['email']; ?>"
                        data-whatevercpfcnjp="<?php echo $linha['cpf_cnjp']; ?>"
                        data-whateverrg="<?php echo $linha['rg']; ?>" data-whatevercep="<?php echo $linha['cep']; ?>"
                        data-whateverrua="<?php echo ucwords(strtolower($linha['rua'])); ?>"
                        data-whatevernumero="<?php echo $linha['numero']; ?>"
                        data-whatevercomplemento="<?php echo $linha['complemento']; ?>"
                        data-whateverbairro="<?php echo $linha['bairro']; ?>"
                        data-whatevercidade="<?php echo $linha['cidade']; ?>"
                        data-whateverestado="<?php echo $linha['estado']; ?>"
                        data-whatevertelefone="<?php echo $linha['telefone']; ?>"
                        data-whateverresidencial="<?php echo $linha['residencial']; ?>"
                        data-whatevercelular="<?php echo $linha['celular']; ?>"
                        data-whateverrecado="<?php echo $linha['recado']; ?>"
                        data-whatevercomercial="<?php echo $linha['comercial']; ?>"
                        data-whateverpagamento_dia="<?php echo $pagamento_dia; ?>">

                        <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Visualizar"></i>
                      </a>
                    </td>

                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#editarCliente" data-whatever="<?php echo $linha['id_cliente']; ?>"
                        data-whatevernome="<?php echo ucwords(strtolower($linha['nome'])); ?>"
                        data-whatevernascimento="<?php echo $nascimento; ?>"
                        data-whateveremail="<?php echo $linha['email']; ?>"
                        data-whatevercpfcnjp="<?php echo $linha['cpf_cnjp']; ?>"
                        data-whateverrg="<?php echo $linha['rg']; ?>" data-whatevercep="<?php echo $linha['cep']; ?>"
                        data-whateverrua="<?php echo ucwords(strtolower($linha['rua'])); ?>"
                        data-whatevernumero="<?php echo $linha['numero']; ?>"
                        data-whatevercomplemento="<?php echo $linha['complemento']; ?>"
                        data-whateverbairro="<?php echo $linha['bairro']; ?>"
                        data-whatevercidade="<?php echo $linha['cidade']; ?>"
                        data-whateverestado="<?php echo $linha['estado']; ?>"
                        data-whatevertelefone="<?php echo $linha['telefone']; ?>"
                        data-whateverresidencial="<?php echo $linha['residencial']; ?>"
                        data-whatevercelular="<?php echo $linha['celular']; ?>"
                        data-whateverrecado="<?php echo $linha['recado']; ?>"
                        data-whatevercomercial="<?php echo $linha['comercial']; ?>"
                        data-whateverpagamento_dia="<?php echo $linha['pagamento_dia']; ?>">
                        <i class="far fa-edit text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Editar"></i></a>
                      <div class="modal">
                    </td>
                    <td class="text text-center">
                      <a href="processa_excluir_clientes.php?id_cliente=<?php echo $linha['id_cliente']; ?>"
                        onClick="return confirm('Deseja realmente deletar a cliente? <?php echo $linha['cliente']; ?>')">
                        <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Excluir"></i></a>
                    </td>
                    </tr>
                  </tbody>
                  <?php

                  }
                  mysqli_close($conn);

                  ?>
              </table>

              <strong>Página
                <?php echo $page_no . " de " . $total_no_of_pages; ?>
              </strong>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                  <?php if ($page_no > 1) {
                    echo "<li><a class='pagination-link' href='?page_no=1'> Primeira Página</a></li>";
                  } ?>

                  <li <?php if ($page_no <= 1) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-previous" <?php if ($page_no > 1) {
                      echo "href='?page_no=$previous_page'";
                    } ?>>Anterior</a>
                  </li>


                  <?php if ($total_no_of_pages <= 15) {
                    for ($counter = 1; $counter <= $total_no_of_pages; $counter++) {

                      if ($counter == $page_no) {
                        echo "<li class='active'><a class='pagination-link is-current'>$counter</a></li>";
                      } else {
                        echo "<li><a class='pagination-link' href='?page_no=$counter'>$counter</a></li>";
                      }
                    }
                  } ?>

                  <li <?php if ($page_no >= $total_no_of_pages) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-next" <?php if ($page_no < $total_no_of_pages) {
                      echo "href='?page_no=$next_page'";
                    } ?>>Próximo</a>
                  </li>

                  <?php if ($page_no < $total_no_of_pages) {
                    echo "<li><a class='pagination-link' href='?page_no=$total_no_of_pages'>Último &rsaquo;&rsaquo;</a></li>";
                  } ?>
                </ul>

              </nav>
              <br>
            </div>
          </div>

        </article>
      </article>
    </div>
  </div>
</section>
</div>



<!-- -----------------------------------MODAL VISUALIZAR CLIENTE----------------------------------------------------------------->


<div class="modal fade" id="visualizarCliente" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">Visualizar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">
        <div class="field-group is-bordered is-horizontal">
          <div class="field">
            <label for="recipient-nome" class="label">Nome</label>
            <div class="control">
              <input type="text" class="input" id="recipient-nome" required="required" name="nome" disabled />
            </div>

          </div>

          <div class="field">
            <label for="recipient-nascimento" class="label">Data de nascimento</label>
            <div class="control">
              <input type="text" class="input" id="recipient-nascimento" required="required" name="nascimento"
                disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-email" class="label">Email</label>
            <div class="control">
              <input type="text" class="input" id="recipient-email" required="required" name="email" disabled />
            </div>

          </div>
        </div>

        <div class="field-group is-horizontal">
          <div class="field">
            <div class="control">
            <label for="recipient-cpf_cnjp" class="label">CPF/CNPJ</label>
              <div class="control">
                <input type="text" class="input" id="recipient-cpf_cnjp" required="required" name="cpf_cnjp" disabled />
              </div>
            </div>

          </div>
        </div>

        <div class="field-group is-horizontal">
          <div class="field">
            <label for="recipient-rg" class="label">RG</label>
            <div class="control" style="width: 180px">
              <input type="text" class="input" id="recipient-rg" required="required" name="rg" disabled />
            </div>

          </div>
        </div>

        <div class="field-group is-horizontal">
          <div class="field">
            <label id="recipient-cep" class="label">CEP</label>
            <div class="control">
              <input class="input" id="recipient-cep" type="text" name="cep" id="cep" maxlength="50"
                onblur="pesquisacep(this.value);" disabled />
            </div>

          </div>
        </div>

        <div class="field-group is-horizontal">
          <div class="field">
            <label for="recipient-rua" class="label">Rua</label>
            <div class="control">
              <input type="text" class="input" id="recipient-rua" required="required" name="rua" disabled />
            </div>

          </div>

          <div class="field">
            <label for="recipient-numero" class="label">Numero</label>
            <div class="control">
              <input type="text" class="input" id="recipient-numero" required="required" name="numero" disabled />
            </div>

          </div>

          <div class="field">
            <label for="recipient-complemento" class="label">Complemento</label>
            <div class="control">
              <input type="text" class="input" id="recipient-complemento" required="required" name="complemento"
                disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-bairro" class="label">Bairro</label>
            <div class="control">
              <input type="text" class="input" id="recipient-bairro" required="required" name="bairro" disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-cidade" class="label">Cidade</label>
            <div class="control">
              <input type="text" class="input" id="recipient-cidade" required="required" name="cidade" disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-estado" class="label">Estado</label>
            <div class="control">
              <input type="text" class="input" id="recipient-estado" required="required" name="estado" disabled />
            </div>

          </div>
        </div>
        <div class="field-group is-horizontal">
          <div class="field">
            <label for="recipient-telefone" class="label">Telefone</label>
            <div class="control">
              <input type="text" class="input" id="recipient-telefone" required="required" name="telefone"
                onkeypress="mask(this, telefone);" onblur="mask(this, telefone);" disabled />
            </div>

          </div>

          <div class="field">
            <label for="recipient-residencial" class="label">Residencial</label>
            <div class="control">
              <input type="text" class="input" id="recipient-residencial" required="required" name="residencial"
                onkeypress="mask(this, residencial);" onblur="mask(this, residencial);" placeholder="residencial"
                disabled />
            </div>

          </div>

          <div class="field">
            <label for="recipient-celular" class="label">Celular</label>
            <div class="control">
              <input type="text" class="input" id="recipient-celular" required="required" name="celular"
                onkeypress="mask(this, celular);" onblur="mask(this, celular);" placeholder="celular" disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-recado" class="label">Recado</label>
            <div class="control">
              <input type="text" class="input" id="recipient-recado" required="required" name="recado"
                onkeypress="mask(this, recado);" onblur="mask(this, recado);" disabled />
            </div>

          </div>
          <div class="field">
            <label for="recipient-comercial" class="label">Comercial</label>
            <div class="control">
              <input type="text" class="input" id="recipient-comercial" required="required" name="comercial"
                onkeypress="mask(this, comercial);" onblur="mask(this, comercial);" placeholder="comercial" disabled />
            </div>

          </div>
        </div>
        <hr />

        <div class="field-group is-horizontal">
          <div class="field">
            <label for="recipient-pagamento_dia" class="label">Pagamento dia</label>
            <div class="control" style="width: 120px">
              <input type="text" class="input" id="recipient-pagamento_dia" required="required" name="pagamento_dia"
                disabled />
            </div>

          </div>
        </div>
        <input type="hidden" name="id" class="form-control" id="id">
      </section>
      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
      </footer>
    </div>
  </div>
</div>



<div class="modal fade" id="editarCliente" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">Editar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">

        <form method="POST" action="processa_edit_clientes.php" enctype="multipart/form-data" id="form_contato">
          <div class="field-group is-bordered is-horizontal">
            <div class="field">
              <label for="recipient-nome" class="label">Nome</label>
              <div class="control">
                <input type="text" class="input" id="recipient-nome" required="required" name="nome" />
              </div>

            </div>

            <div class="field">
              <label for="recipient-nascimento" class="label">Data de nascimento</label>
              <div class="control">
                <input type="text" class="input" id="recipient-nascimento" required="required" name="nascimento" />
              </div>

            </div>
            <div class="field">
              <label for="recipient-email" class="label">Email</label>
              <div class="control">
                <input type="text" class="input" id="recipient-email" required="required" name="email" />
              </div>

            </div>
          </div>

          <div class="field-group is-horizontal">
            <div class="field">
              <div class="control">
                <label for="recipient-cpf" class="radio">
                <label for="recipient-cpf_cnjp" class="label">CPF/CNPJ</label>
                <div class="control">
                  <input type="text" class="input" id="recipient-cpf_cnjp" required="required" name="cpf_cnjp" />
                </div>
              </div>

            </div>
          </div>

          <div class="field-group is-horizontal">
            <div class="field">
              <label for="recipient-rg" class="label">RG</label>
              <div class="control" style="width: 180px">
                <input type="text" class="input" id="recipient-rg" required="required" name="rg" />
              </div>

            </div>
          </div>

          <div class="field-group is-horizontal">
            <div class="field">
              <label id="recipient-cep" class="label">CEP</label>
              <div class="control">
                <input class="input" id="recipient-cep" type="text" name="cep" id="cep" maxlength="50"
                  onblur="pesquisacep(this.value);">
              </div>

            </div>
          </div>

          <div class="field-group is-horizontal">
            <div class="field">
              <label for="recipient-rua" class="label">Rua</label>
              <div class="control">
                <input type="text" class="input" id="recipient-rua" required="required" name="rua" />
              </div>

            </div>

            <div class="field">
              <label for="recipient-numero" class="label">Numero</label>
              <div class="control">
                <input type="text" class="input" id="recipient-numero" required="required" name="numero" />
              </div>

            </div>

            <div class="field">
              <label for="recipient-complemento" class="label">Complemento</label>
              <div class="control">
                <input type="text" class="input" id="recipient-complemento" required="required" name="complemento" />
              </div>

            </div>
            <div class="field">
              <label for="recipient-bairro" class="label">Bairro</label>
              <div class="control">
                <input type="text" class="input" id="recipient-bairro" required="required" name="bairro" />
              </div>

            </div>
            <div class="field">
              <label for="recipient-cidade" class="label">Cidade</label>
              <div class="control">
                <input type="text" class="input" id="recipient-cidade" required="required" name="cidade" />
              </div>

            </div>
            <div class="field">
              <label for="recipient-estado" class="label">Estado</label>
              <div class="control">
                <input type="text" class="input" id="recipient-estado" required="required" name="estado" />
              </div>

            </div>
          </div>
          <div class="field-group is-horizontal">
            <div class="field">
              <label for="recipient-telefone" class="label">Telefone</label>
              <div class="control">
                <input type="text" class="input" id="recipient-telefone" required="required" name="telefone"
                  onkeypress="mask(this, telefone);" onblur="mask(this, telefone);" />
              </div>

            </div>

            <div class="field">
              <label for="recipient-residencial" class="label">Residencial</label>
              <div class="control">
                <input type="text" class="input" id="recipient-residencial" required="required" name="residencial"
                  onkeypress="mask(this, residencial);" onblur="mask(this, residencial);" placeholder="residencial" />
              </div>

            </div>

            <div class="field">
              <label for="recipient-celular" class="label">Celular</label>
              <div class="control">
                <input type="text" class="input" id="recipient-celular" required="required" name="celular"
                  onkeypress="mask(this, celular);" onblur="mask(this, celular);" placeholder="celular" />
              </div>

            </div>
            <div class="field">
              <label for="recipient-recado" class="label">Recado</label>
              <div class="control">
                <input type="text" class="input" id="recipient-recado" required="required" name="recado"
                  onkeypress="mask(this, recado);" onblur="mask(this, recado);">
              </div>

            </div>
            <div class="field">
              <label for="recipient-comercial" class="label">Comercial</label>
              <div class="control">
                <input type="text" class="input" id="recipient-comercial" required="required" name="comercial"
                  onkeypress="mask(this, comercial);" onblur="mask(this, comercial);" placeholder="comercial" />
              </div>

            </div>
          </div>
          <hr />

          <div class="field-group is-horizontal">
            <div class="field">
              <label for="recipient-pagamento_dia" class="label">Pagamento dia</label>
              <div class="control" style="width: 120px">
                <input type="text" class="input" id="recipient-pagamento_dia" required="required"
                  name="pagamento_dia" />
              </div>

            </div>
          </div>
          <input type="hidden" name="id" class="form-control" id="id">
      </section>
      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
        <button type="submit" class="button">Salvar Alterações</button>
        <button type="reset" class="button">Limpar</button>
      </footer>
      </form>
    </div>
  </div>
</div>

<?php include_once('static/rodape.php'); ?>


<script>
  $(function () {
    $("#form_contato").validate();
  });
</script>

<!-- -----------------------------------SCRIPT MODAL EDITAR CLIENTE----------------------------------------------------------------->
<script type="text/javascript">
  $('#editarCliente').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientnome = button.data('whatevernome')
    var recipientnascimento = button.data('whatevernascimento')
    var recipientemail = button.data('whateveremail')
    var recipientcpfcnjp = button.data('whatevercpfcnjp')
    var recipientrg = button.data('whateverrg')
    var recipientcep = button.data('whatevercep')
    var recipientrua = button.data('whateverrua')
    var recipientnumero = button.data('whatevernumero')
    var recipientcomplemento = button.data('whatevercomplemento')
    var recipientbairro = button.data('whateverbairro')
    var recipientcidade = button.data('whatevercidade')
    var recipientestado = button.data('whateverestado')
    var recipienttelefone = button.data('whatevertelefone')
    var recipientresidencial = button.data('whateverresidencial')
    var recipientcelular = button.data('whatevercelular')
    var recipientrecado = button.data('whateverrecado')
    var recipientcomercial = button.data('whatevercomercial')
    var recipientpagamento_dia = button.data('whateverpagamento_dia')

    var modal = $(this)
    modal.find('.modal-title').text('EDITAR CLIENTE CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-nome').val(recipientnome)
    modal.find('#recipient-nascimento').val(recipientnascimento)
    modal.find('#recipient-email').val(recipientemail)
    modal.find('#recipient-cpf_cnjp').val(recipientcpfcnjp)
    modal.find('#recipient-rg').val(recipientrg)
    modal.find('#recipient-cep').val(recipientcep)
    modal.find('#recipient-rua').val(recipientrua)
    modal.find('#recipient-numero').val(recipientnumero)
    modal.find('#recipient-complemento').val(recipientcomplemento)
    modal.find('#recipient-bairro').val(recipientbairro)
    modal.find('#recipient-cidade').val(recipientcidade)
    modal.find('#recipient-estado').val(recipientestado)
    modal.find('#recipient-telefone').val(recipienttelefone)
    modal.find('#recipient-residencial').val(recipientresidencial)
    modal.find('#recipient-celular').val(recipientcelular)
    modal.find('#recipient-recado').val(recipientrecado)
    modal.find('#recipient-comercial').val(recipientcomercial)
    modal.find('#recipient-pagamento_dia').val(recipientpagamento_dia)

  })
</script>

<!-- -----------------------------------SCRIPT MODAL VISUALIZAR CLIENTE----------------------------------------------------------------->
<script type="text/javascript">
  $('#visualizarCliente').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientnome = button.data('whatevernome')
    var recipientnascimento = button.data('whatevernascimento')
    var recipientemail = button.data('whateveremail')
    var recipientcpfcnjp = button.data('whatevercpfcnjp')
    var recipientrg = button.data('whateverrg')
    var recipientcep = button.data('whatevercep')
    var recipientrua = button.data('whateverrua')
    var recipientnumero = button.data('whatevernumero')
    var recipientcomplemento = button.data('whatevercomplemento')
    var recipientbairro = button.data('whateverbairro')
    var recipientcidade = button.data('whatevercidade')
    var recipientestado = button.data('whateverestado')
    var recipienttelefone = button.data('whatevertelefone')
    var recipientresidencial = button.data('whateverresidencial')
    var recipientcelular = button.data('whatevercelular')
    var recipientrecado = button.data('whateverrecado')
    var recipientcomercial = button.data('whatevercomercial')
    var recipientpagamento_dia = button.data('whateverpagamento_dia')

    var modal = $(this)
    modal.find('.modal-title').text('VISUALIZAR CLIENTE CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-nome').val(recipientnome)
    modal.find('#recipient-nascimento').val(recipientnascimento)
    modal.find('#recipient-email').val(recipientemail)
    modal.find('#recipient-cpf_cnjp').val(recipientcpfcnjp)
    modal.find('#recipient-rg').val(recipientrg)
    modal.find('#recipient-cep').val(recipientcep)
    modal.find('#recipient-rua').val(recipientrua)
    modal.find('#recipient-numero').val(recipientnumero)
    modal.find('#recipient-complemento').val(recipientcomplemento)
    modal.find('#recipient-bairro').val(recipientbairro)
    modal.find('#recipient-cidade').val(recipientcidade)
    modal.find('#recipient-estado').val(recipientestado)
    modal.find('#recipient-telefone').val(recipienttelefone)
    modal.find('#recipient-residencial').val(recipientresidencial)
    modal.find('#recipient-celular').val(recipientcelular)
    modal.find('#recipient-recado').val(recipientrecado)
    modal.find('#recipient-comercial').val(recipientcomercial)
    modal.find('#recipient-pagamento_dia').val(recipientpagamento_dia)
  })
</script>


<script>
  $(document).ready(function () {
    $(function () {
      //Pesquisar os cursos sem refresh na página
      $("#pesquisa_cliente").keyup(function () {

        var pesquisa_estacionamento = $(this).val();

        //Verificar se há algo digitado
        if (pesquisa_estacionamento != null) {
          var dados = {
            palavra: pesquisa_estacionamento
          }
          $.post('busca_cliente.php', dados, function (retorna) {
            //Mostra dentro da ul os resultado obtidos
            $(".resultado_cliente").html(retorna);
          });
        } else {
          $(".resultado_cliente").html('');
        }
      });
    });

  });
</script>