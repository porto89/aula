<?php
session_start();
//include_once('static/cabecalho.php');
//include_once('static/rodape.php');
include('config/conexao.php');
// include_once("config/seguranca.php");
// seguranca_adm();
$consulta = "SELECT * FROM estadas ";
$resultado = mysqli_query($conn, $consulta);
?>


<?php
if (isset($_SESSION['error'])) {
  echo $_SESSION['error'];
  unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
  echo $_SESSION['success'];
  unset($_SESSION['success']);
}


$busca = $_POST['palavra'];
$busca = "SELECT * FROM estadas WHERE nome LIKE '%$busca%'";
$resultado = mysqli_query($conn, $busca);
?>

<table class="table table-bordered table-hover table-sm table-responsive-xl resultado_estada">

  <thead>
    <tr class="bg-dark text text-white">
      <th scope="col">ID</th>
      <th scope="col">Nome de funcionario</th>
      <th scope="col">Placa de veiculo</th>
      <th scope="col">Endereço de estacionamento</th>
      <th scope="col">Data de entrada</th>
      <th scope="col">Hora de entrada</th>
      <th scope="col">Data de saida</th>
      <th scope="col">Hora de entrada</th>
      <th scope="col">valor</th>
      <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
    </tr>
  </thead>
  <tbody>
    <?php

    while ($linha = mysqli_fetch_assoc($resultado)) {
      $id_estada = $linha['id_estada'];
      $nome = $linha['nome'];
      $placa = $linha['placa'];
      $endereco = $linha['endereco'];
      $data_entrada = $linha['data_entrada'];
      $hora_entrada = $linha['hora_entrada'];
      $data_saida = $linha['data_saida'];
      $hora_saida = $linha['hora_saida'];
      $valor = $linha['valor'];
      ?>
      <td>
        <?= $linha['id_estada'] ?>
      </td>
      <td>
        <?= $linha['nome'] ?>
      </td>
      <td>
        <?= $linha['placa'] ?>
      </td>
      <td>
        <?= $linha['endereco'] ?>
      </td>
      <td>
        <?= $linha['data_entrada'] ?>
      </td>
      <td>
        <?= $linha['hora_entrada'] ?>
      </td>
      <td>
        <?= $linha['data_saida'] ?>
      </td>
      <td>
        <?= $linha['hora_saida'] ?>
      </td>
      <td>
        <?= $linha['valor'] ?>
      </td>

      <td class="text text-center">
        <a href="#" data-toggle="modal" 
        data-backdrop="static" 
        data-keyboard="false" 
        data-target="#visualizarEstada"
        data-whatever="<?php echo $linha['id_estada']; ?>"
        data-whatevernome="<?php echo $linha['nome']; ?>"
        data-whateverplaca="<?php echo $linha['placa']; ?>"
        data-whateverendereco="<?php echo $linha['endereco']; ?>"
        data-whateverdata_entrada="<?php echo $linha['data_entrada']; ?>"
        data-whateverhora_entrada="<?php echo $linha['hora_entrada']; ?>"
        data-whateverdata_saida="<?php echo $linha['data_saida']; ?>"
        data-whateverhora_saida="<?php echo $linha['hora_saida']; ?>"
        data-whatevervalor="<?php echo $linha['valor']; ?>"
        
        >

          <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Visualizar"></i>
        </a>
      </td>

      <td class="text text-center">
        <a href="#" data-toggle="modal" 
        data-backdrop="static" 
        data-keyboard="false" 
        data-target="#editarEstada"
        data-whatever="<?php echo $linha['id_estada']; ?>"
        data-whatevernome="<?php echo $linha['nome']; ?>"
        data-whateverplaca="<?php echo $linha['placa']; ?>"
        data-whateverendereco="<?php echo $linha['endereco']; ?>"
        data-whateverdata_entrada="<?php echo $linha['data_entrada']; ?>"
        data-whateverhora_entrada="<?php echo $linha['hora_entrada']; ?>"
        data-whateverdata_saida="<?php echo $linha['data_saida']; ?>"
        data-whateverhora_saida="<?php echo $linha['hora_saida']; ?>"
        data-whatevervalor="<?php echo $linha['valor']; ?>"
        >

          <i class="far fa-edit text text-dark" 
          data-bs-toggle="tooltip" data-bs-placement="top" title="Editar"></i></a>
        <div class="modal">
      </td>
      <td class="text text-center">
        <a href="processa_excluir_estadas.php?id_estada=<?php echo $linha['id_estada']; ?>"
          onClick="return confirm('Deseja realmente deletar o veícluo? <?php echo $linha['estada']; ?>')">
          <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
            title="Excluir"></i></a>
      </td>
      </tr>
    </tbody>
    <?php

    }
    mysqli_close($conn);

    ?>
</table>