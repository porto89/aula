<?php
session_start();
include_once('static/cabecalho.php');

include('config/conexao.php');
include_once("config/seguranca.php");
seguranca_adm();
$consulta = "SELECT * FROM clientes ";
$resultado = mysqli_query($conn, $consulta);
?>


<?php
if (isset($_SESSION['error'])) {
  echo $_SESSION['error'];
  unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
  echo $_SESSION['success'];
  unset($_SESSION['success']);
}
?>
<?php include_once('static/nav.php'); ?>


<section class="section is-main-section">
  <div class="tile is-ancestor">
    <div class="tile is-parent">
      <div class="card tile is-child">
        <div class="card-content">
          <div class="level is-mobile">
            <div class="level-item">
              <div class="is-widget-label">
                <?php
                $result_count = mysqli_query(
                  $conn,
                  "SELECT COUNT(*) As total_clientes FROM `clientes`"
                );
                $total_clientes = mysqli_fetch_array($result_count);
                $total_clientes = $total_clientes['total_clientes']; ?>
                <h3 class="subtitle is-spaced">Clientes</h3>
                <h1 class="title">
                  <?php echo $total_clientes ?>
                </h1>

              </div>
            </div>
            <div class="level-item has-widget-icon">
              <div class="is-widget-icon">
                <span class="icon has-text-primary is-large"><i class="mdi mdi-account-multiple mdi-48px"></i></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tile is-parent">
      <div class="card tile is-child">
        <div class="card-content">
          <div class="level is-mobile">
            <div class="level-item">
              <div class="is-widget-label">
                <?php
                $result_count = mysqli_query(
                  $conn,
                  "SELECT COUNT(*) As total_estadas FROM `estadas`"
                );
                $total_estadas = mysqli_fetch_array($result_count);
                $total_estadas = $total_estadas['total_estadas']; ?>
                <h3 class="subtitle is-spaced">Estadas</h3>
                <h1 class="title">
                  <?php echo $total_estadas ?>
                </h1>
              </div>
            </div>
            <div class="level-item has-widget-icon">
              <div class="is-widget-icon">
                <span class="icon has-text-primary is-large"><i class="mdi mdi-account-multiple mdi-48px"></i></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tile is-parent">
      <div class="card tile is-child">
        <div class="card-content">
          <div class="level is-mobile">
            <div class="level-item">
              <div class="is-widget-label">
                <?php
                $result_count = mysqli_query(
                  $conn,
                  "SELECT SUM(valor) AS total_valor FROM `estadas`"
                );
                $total_valor = mysqli_fetch_array($result_count);
                $total_valor = $total_valor['total_valor']; ?>
                <h3 class="subtitle is-spaced">Total</h3>
                <h1 class="title">R$
                  <?php echo number_format($total_valor, 2); ?>
                </h1>
              </div>
            </div>
            <div class="level-item has-widget-icon">
              <div class="is-widget-icon">
                <span class="icon has-text-info is-large"><i class="mdi mdi-cart-outline mdi-48px"></i></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

</section>
</div>

<?php include_once('static/rodape.php'); ?>

<script>
  const fileInput = document.querySelector(
    "#file-js-example input[type=file]"
  );
  fileInput.onchange = () => {
    if (fileInput.files.length > 0) {
      const fileName = document.querySelector("#file-js-example .file-name");
      fileName.textContent = fileInput.files[0].name;
    }
  };
</script>