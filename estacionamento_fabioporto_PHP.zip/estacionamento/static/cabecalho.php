<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Inicio</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css"
    />
    <link rel="stylesheet" href="/estacionamento/static/css/field_group.css" />
    <link rel="stylesheet" href="/estacionamento/static/css/menubc.css" />

    <script src="/estacionamento/static/js/calendario.js"></script>




  </head>
  <nav class="navbar is-transparent is-info">
      <div class="navbar-brand">
        <a class="navbar-item">
          <img
            src="/estacionamento/static/img/logo.png"
            alt="Bulma: a modern CSS framework based on Flexbox"
            width="112"
            height="28"
          />
        </a>
        <div
          class="navbar-burger"
          data-target="navbarExampleTransparentExample"
        >
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>

      <div id="navbarExampleTransparentExample" class="navbar-menu">
        <div class="navbar-start">
          <a class="navbar-item" href="index.php"> Início </a>
        </div>
        <div class="level-right">
          <div class="level-item">
            <script language="javascript" type="text/javascript">
              document.write(
                "<h1> Hoje é " +
                  dia[novo.getDay()] +
                  ", " +
                  novo.getDate() +
                  " de " +
                  mes[novo.getMonth()] +
                  " de " +
                  novo.getFullYear() +
                  ". </h1>"
              );
            </script>
          </div>
        </div>

        <div class="navbar-end">
          <div class="navbar-item">
            <div class="buttons">
              <a href="sair.php" class="button is-light"> Sair </a>
            </div>
          </div>
        </div>
      </div>
    </nav>

<body>