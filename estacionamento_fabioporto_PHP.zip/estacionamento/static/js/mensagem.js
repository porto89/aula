$("#form_contato").validate({
  rules: {
    nome: {
      required: true,
    },
    endereco: {
      required: true,
    },
    email: {
      required: true,
    },
    mensagem: {
      required: true,
    },
    nascimento: {
      required: true,
    },
    cpf_cnjp: {
      required: true,
    },
    rg: {
      required: true,
    },
    cep: {
      required: true,
    },
    rua: {
      required: true,
    },
    numero: {
      required: true,
    },
    complemento: {
      required: true,
    },
    bairro: {
      required: true,
    },
    cidade: {
      required: true,
    },
    estado: {
      required: true,
    },
    telefone: {
      required: true,
    },
    celular: {
      required: true,
    },
    modelo: {
      required: true,
    },
    cor: {
      required: true,
    },
    placa: {
      required: true,
    },
    ano: {
      required: true,
    },
    matricula: {
      required: true,
    },
    data_admissao: {
      required: true,
    },
    turno: {
      required: true,
    },
    pagamento_dia: {
      required: true,
    },
    foto: {
      required: true,
    },
    endereco_estacionamento: {
      required: true,
    },
    placa_veiculo: {
      required: true,
    },
    nome_funcionario: {
      required: true,
    },
    data_entrada: {
      required: true,
    },
    hora_entrada: {
      required: true,
    },
    data_saida: {
      required: true,
    },
    hora_saida: {
      required: true,
    },
    valor: {
      required: true,
    },
  },
  messages: {
    nome: {
      required: "Por favor, informe seu nome",
    },
    endereco: {
      required: "Por favor, informe seu endereco",
      //minlength:"O nome deve ter pelo menos 3 caracteres"
    },
    email: {
      required: "É necessário informar um email",
    },
    mensagem: {
      required: "A mensagem não pode ficar em branco",
    },

    nascimento: {
      required: "Por favor, informe seu endereco",
    },
    cpf_cnjp: {
      required: "Por favor, informe seu CPF ou CNJP",
    },
    rg: {
      required: "Por favor, informe seu RG",
    },
    cep: {
      required: "Por favor, informe seu CEP",
    },
    rua: {
      required: "Por favor, informe sua rua",
    },
    numero: {
      required: "Por favor, informe seu numero",
    },
    complemento: {
      required: "Por favor, informe seu complemento",
    },
    bairro: {
      required: "Por favor, informe seu bairro",
    },
    cidade: {
      required: "Por favor, informe seu cidade",
    },
    estado: {
      required: "Por favor, informe seu estado",
    },
    telefone: {
      required: "Por favor, informe seu telefone",
    },
    celular: {
      required: "Por favor, informe seu celular",
    },
    modelo: {
      required: "Por favor, informe seu modelo",
    },
    cor: {
      required: "Por favor, informe seu cor",
    },
    placa: {
      required: "Por favor, informe sua placa",
    },
    ano: {
      required: "Por favor, informe seu ano",
    },
    matricula: {
      required: "Por favor, informe sua matrícula",
    },
    data_admissao: {
      required: "Por favor, informe sua data de admissão",
    },
    turno: {
      required: "Por favor, informe seu turno",
    },
    pagamento_dia: {
      required: "Por favor, informe seu pagamento dia",
    },
    foto: {
      required: "Por favor, Image coudn't be uploaded.",
    },
    nome_funcionario: {
      required: "Por favor, informe seu nome",
    },
    placa_veiculo: {
      required: "Por favor, informe sua placa veículo",
    },
    endereco_estacionamento: {
      required: "Por favor, informe seu endereço",
    },
    data_entrada: {
      required: "Por favor, informe sua data entrada",
    },
    hora_entrada: {
      required: "Por favor, informe sua hora entrada",
    },
    data_saida: {
      required: "Por favor, informe sua data saida",
    },
    hora_saida: {
      required: "Por favor, informe sua hora saida",
    },
    valor: {
      required: "Por favor, informe seu valor",
    },
  },
});
