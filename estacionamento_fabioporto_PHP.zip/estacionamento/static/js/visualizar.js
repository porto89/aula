$('#visualizarEstacionamento').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientendereco = button.data('whateverendereco')

    
    var modal = $(this)
    modal.find('.modal-title').text('VISUALIZAR ESTACIONAMETO CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-endereco').val(recipientendereco)


})