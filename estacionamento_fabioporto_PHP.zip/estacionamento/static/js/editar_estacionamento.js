$('#editarEstacionamento').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget)
    var recipient = button.data('whatever')
    var recipientendereco = button.data('whateverendereco')

    var modal = $(this)
    modal.find('.modal-title').text('EDITAR CLIENTE CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-endereco').val(recipientendereco)


})