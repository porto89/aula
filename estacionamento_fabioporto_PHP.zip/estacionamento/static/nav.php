

    <br />
    <div class="columns is-fullheight">
      <div class="column is-2 is-sidebar-menu is-hidden-mobile">
        <aside class="menu">
          <ul class="menu-list">
            <li>
              <a class="menu1 panel-heading has-text-white">Cadastrar</a>
              <ul>
                
                <li class="nav-item me-3 me-lg-0">
                  <a class="nav-link text-white" href="cliente.php">
                    <img src="/estacionamento/static/img/account.png" alt="An example icon" style="width:24px;height:24px" /> Clientes</a>
              </li>
                <li class="nav-item me-3 me-lg-0">
                  <a class="nav-link text-white" href="funcionario.php">
                    <img src="/estacionamento/static/img/account-tie (1).png" alt="An example icon" style="width:24px;height:24px" /> Funcionarios</a>
              </li>
                
              <li class="nav-item me-3 me-lg-0">
                <a class="nav-link text-white" href="veiculo.php">
                  <img src="/estacionamento/static/img/bed-double.png" alt="An example icon" style="width:24px;height:24px" /> Veículos</a>
            </li>
            <li class="nav-item me-3 me-lg-0">
              <a class="nav-link text-white" href="estacionamento.php">
                <img src="/estacionamento/static/img/car-parking-lights.png" alt="An example icon" style="width:24px;height:24px" /> Estacionamentos</a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link text-white" href="estada.php">
              <img src="/estacionamento/static/img/boom-gate-up.png" alt="An example icon" style="width:24px;height:24px" /> Estadas</a>
        </li>
              </ul>
            </li>
            <li>
              <a class="menu1 panel-heading has-text-white">Consultar</a>
              <ul>
                <li class="nav-item me-3 me-lg-0">
                  <a class="nav-link text-white" href="consultar_cliente.php">
                    <img src="/estacionamento/static/img/account.png" alt="An example icon" style="width:24px;height:24px" /> Clientes</a>
              </li>
                <li class="nav-item me-3 me-lg-0">
                  <a class="nav-link text-white" href="consultar_funcionario.php">
                    <img src="/estacionamento/static/img/account-tie (1).png" alt="An example icon" style="width:24px;height:24px" /> Funcionarios</a>
              </li>
                
              <li class="nav-item me-3 me-lg-0">
                <a class="nav-link text-white" href="consultar_veiculo.php">
                  <img src="/estacionamento/static/img/bed-double.png" alt="An example icon" style="width:24px;height:24px" /> Veículos</a>
            </li>
            <li class="nav-item me-3 me-lg-0">
              <a class="nav-link text-white" href="consultar_estacionamento.php">
                <img src="/estacionamento/static/img/car-parking-lights.png" alt="An example icon" style="width:24px;height:24px" /> Estacionamentos</a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link text-white" href="consultar_estada.php">
              <img src="/estacionamento/static/img/boom-gate-up.png" alt="An example icon" style="width:24px;height:24px" /> Estadas</a>
        </li>
              </ul>
            </li>
          </ul>
          <hr />
          <div class="tags has-addons is-centered">
            <span class="tag is-dark">Versão</span>
            <span class="tag is-info">1.0.0</span>
          </div>
        </aside>
      </div>

      
      
    


