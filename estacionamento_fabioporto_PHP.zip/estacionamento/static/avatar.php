<?php 

    
        // Set image placement folder
        $target_dir = "image/";
        // Get file path
        $foto = $target_dir . basename($_FILES["fotoUpload"]["name"]);
        // Get file extension
        $imageExt = strtolower(pathinfo($foto, PATHINFO_EXTENSION));
        // Allowed file types
        $allowd_file_ext = array("jpg", "jpeg", "png");
        
        if (!file_exists($_FILES["fotoUpload"]["tmp_name"])) {
           $resMessage = array(
               "status" => "alert-danger",
               "message" => "Select image to upload."
           );
        } else if (!in_array($imageExt, $allowd_file_ext)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "Allowed file formats .jpg, .jpeg and .png."
            );            
        } else if ($_FILES["fotoUpload"]["size"] > 2097152) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File is too large. File size should be less than 2 megabytes."
            );
        } else if (file_exists($foto)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File already exists."
            );
        } 
    
?>