<!-- BOOTSTRAP V4.5.3 -->
<!-- Optional JavaScript  SEQUENCIA DE PLUGINS PARA UM CORRETO FUNCIONAMENTO -->
<!-- jQuery 1º, Popper.js 2º, Bootstrap JS 3º -->

<script
      defer
      src="https://use.fontawesome.com/releases/v5.14.0/js/all.js"
    ></script>


<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" />

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
<script src="/estacionamento/static/js/mensagem.js"></script>
<script src="/estacionamento/static/js/listas.js"></script>
<script src="/estacionamento/static/js/editar_estacionameto.js"></script>
<script src="/static/js/visualizar_estacionamento.js"></script>

<style>
       .error{
             color:red
       }
</style>

    <footer class="footer has-background-info-dark p-5">
      <div class="container">
        <div class="columns">
          <div class="column is-2 has-text-white">© 2022 Estcionamento</div>
          <div class="column is-8"></div>
          <div class="column is-2 has-text-centered">
            <span class="icon has-text-warning">
              <i class="fab fa-facebook-square fa-2x mr-2"></i>
              <i class="fab fa-twitter-square fa-2x mr-2"></i>
              <i class="fab fa-instagram-square fa-2x mr-2"></i>
            </span>
          </div>
        </div>
      </div>
    </footer>
</body>


</html>