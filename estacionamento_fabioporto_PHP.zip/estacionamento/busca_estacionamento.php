<?php
session_start();
//include_once('static/cabecalho.php');
//include_once('static/rodape.php');
include('config/conexao.php');
// include_once("config/seguranca.php");
// seguranca_adm();
$consulta = "SELECT * FROM estacionamentos ";
$resultado = mysqli_query($conn, $consulta);
?>


<?php
if (isset($_SESSION['error'])) {
    echo $_SESSION['error'];
    unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
    echo $_SESSION['success'];
    unset($_SESSION['success']);
}


$busca = $_POST['palavra'];
$busca = "SELECT * FROM estacionamentos WHERE endereco LIKE '%$busca%'";
$resultado = mysqli_query($conn, $busca);
?>

<table class="table table-bordered table-hover table-sm table-responsive-xl resultado_estacionamento">
    <thead>
        <tr class="bg-dark text text-white">
            <th scope="col">CÓD</th>
            <th scope="col">ENDEREÇO</th>
            <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
        </tr>
    </thead>
    <?php
    while ($linha = mysqli_fetch_assoc($resultado)) {
        $id_estacionamento = $linha['id_estacionamento'];
        $endereco = $linha['endereco'];    
    ?>
        <tbody>
            <tr>
                <td><?php echo $id_estacionamento ?></td>
                <td><?php echo $endereco; ?></td>
                <td class="text text-center">

                    <a href="#" data-toggle="modal" 
                    data-backdrop="static" 
                    data-keyboard="false" 
                    data-target="#visualizarEstacionamento" 
                    data-whatever="<?php echo $linha['id_estacionamento']; ?>" 
                    data-whateverendereco="<?php echo $linha['endereco']; ?>">

                        <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Visualizar"></i>
                    </a>
                </td>

                <td class="text text-center">
                    <a href="#" data-toggle="modal" 
                    data-backdrop="static" 
                    data-keyboard="false" 
                    data-target="#editarEstacionamento" 
                    data-whatever="<?php echo $linha['id_estacionamento']; ?>" 
                    data-whateverendereco="<?php echo $linha['endereco']; ?>">

                        <i class="far fa-edit text text-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Editar"></i></a>
                </td>
                <td class="text text-center">
                    <a href="processa_excluir_estacionamentos.php?id_estacionamento=<?php echo $linha['id_estacionamento']; ?>" onClick="return confirm('Deseja realmente deletar o estacionamento? <?php echo $linha['estacionamento']; ?>')">
                        <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Excluir"></i></a>
                </td>

            </tr>
        </tbody>
    <?php } ?>
</table>




