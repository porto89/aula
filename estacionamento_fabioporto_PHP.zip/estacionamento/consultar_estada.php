<?php
session_start();
include_once('static/cabecalho.php');

include('config/conexao.php');
include_once("config/seguranca.php");
seguranca_adm();
$consulta = "SELECT * FROM estadas ";
$resultado = mysqli_query($conn, $consulta);

if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
  $page_no = $_GET['page_no'];
} else {
  $page_no = 1;
}

$total_records_per_page = 10;

$offset = ($page_no - 1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";

$result_count = mysqli_query(
  $conn,
  "SELECT COUNT(*) As total_records FROM `estadas`"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
?>

<style>
  .table__wrapper {
    overflow-x: auto;
  }
</style>

    <section class="section has-background-link-light">
      <nav class="breadcrumb is-centered" aria-label="breadcrumbs">
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li><a href="consultar_estada.php">Consultar Estadas</a></li>
        </ul>
      </nav>
      <div class="container">
        <article class="panel is-info">
          <p class="panel-heading">Consultar Estadas</p>
          <div class="box">
            
          <div class="table__wrapper">

              <div class="control is-expanded">
                <label class="label p-2 mt-2">Placa: </label>
                <input class="input" type="text" name="pesquisa_estada" id="pesquisa_estada" value="" placeholder=""
                  required autofocus>

              </div>

              <br>

              <table class="table is-table is-bordered is-striped is-narrow is-hoverable is-fullwidth resultado_estada">

                <thead>
                  <tr class="bg-dark text text-white">
                    <th scope="col">ID</th>
                    <th scope="col">Nome de funcionario</th>
                    <th scope="col">Placa de veiculo</th>
                    <th scope="col">Endereço de estacionamento</th>
                    <th scope="col">Data de entrada</th>
                    <th scope="col">Hora de entrada</th>
                    <th scope="col">Data de saida</th>
                    <th scope="col">Hora de entrada</th>
                    <th scope="col">valor</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT * FROM `estadas` LIMIT $offset, $total_records_per_page"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) {
                    $id_estada = $linha['id_estada'];
                    $nome_funcionario = $linha['nome_funcionario'];
                    $placa_veiculo = $linha['placa_veiculo'];
                    $endereco_estacionamento = $linha['endereco_estacionamento'];
                    $data_entrada = $linha['data_entrada'];
                    $data_entrada = date('d/m/Y', strtotime($data_entrada));
                    $hora_entrada = $linha['hora_entrada'];
                    $data_saida = $linha['data_saida'];
                    $data_saida = date('d/m/Y', strtotime($data_saida));
                    $hora_saida = $linha['hora_saida'];
                    $valor = $linha['valor'];
                    $valor = str_replace(",", ".", str_replace(".", "", $linha['valor']));
                    ?>
                    <td>
                      <?= $linha['id_estada'] ?>
                    </td>
                    <td>
                      <?= $linha['nome_funcionario'] ?>
                    </td>
                    <td>
                      <?= $linha['placa_veiculo'] ?>
                    </td>
                    <td>
                      <?= $linha['endereco_estacionamento'] ?>
                    </td>
                    <td>
                      <?= $linha['data_entrada'] ?>
                    </td>
                    <td>
                      <?= $linha['hora_entrada'] ?>
                    </td>
                    <td>
                      <?= $linha['data_saida'] ?>
                    </td>
                    <td>
                      <?= $linha['hora_saida'] ?>
                    </td>
                    <td>
                      <?= $linha['valor'] ?>
                    </td>

                    </tr>
                  </tbody>
                  <?php

                  }
                  mysqli_close($conn);

                  ?>
              </table>

              <strong>Página
                <?php echo $page_no . " de " . $total_no_of_pages; ?>
              </strong>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                  <?php if ($page_no > 1) {
                    echo "<li><a class='pagination-link' href='?page_no=1'> Primeira Página</a></li>";
                  } ?>

                  <li <?php if ($page_no <= 1) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-previous" <?php if ($page_no > 1) {
                      echo "href='?page_no=$previous_page'";
                    } ?>>Anterior</a>
                  </li>


                  <?php if ($total_no_of_pages <= 15) {
                    for ($counter = 1; $counter <= $total_no_of_pages; $counter++) {

                      if ($counter == $page_no) {
                        echo "<li class='active'><a class='pagination-link is-current'>$counter</a></li>";
                      } else {
                        echo "<li><a class='pagination-link' href='?page_no=$counter'>$counter</a></li>";
                      }
                    }
                  } ?>

                  <li <?php if ($page_no >= $total_no_of_pages) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-next" <?php if ($page_no < $total_no_of_pages) {
                      echo "href='?page_no=$next_page'";
                    } ?>>Próximo</a>
                  </li>

                  <?php if ($page_no < $total_no_of_pages) {
                    echo "<li><a class='pagination-link' href='?page_no=$total_no_of_pages'>Último &rsaquo;&rsaquo;</a></li>";
                  } ?>
                </ul>

              </nav>
              <br>
            </div>


          </div>
        </article>
      </div>
    </section>

    <?php include_once('static/rodape.php'); ?>
  <script>
    const fileInput = document.querySelector(
      "#file-js-example input[type=file]"
    );
    fileInput.onchange = () => {
      if (fileInput.files.length > 0) {
        const fileName = document.querySelector("#file-js-example .file-name");
        fileName.textContent = fileInput.files[0].name;
      }
    };
  </script>

<script>
  $(document).ready(function () {
    $(function () {
      //Pesquisar 
      $("#pesquisa_estada").keyup(function () {

        var pesquisa_estada = $(this).val();

        //Verificar se  digitado
        if (pesquisa_estada != null) {
          var dados = {
            palavra: pesquisa_estada
          }
          $.post('busca_veiculo.php', dados, function (retorna) {
            //Mostra  resultado obtidos
            $(".resultado_estada").html(retorna);
          });
        } else {
          $(".resultado_estada").html('');
        }
      });
    });

  });
</script>