<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();

$nome_funcionario = mysqli_real_escape_string($conn, $_POST['nome_funcionario']);
$placa_veiculo = mysqli_real_escape_string($conn, strtolower($_POST['placa_veiculo']));
$endereco_estacionamento = mysqli_real_escape_string($conn, strtolower($_POST['endereco_estacionamento']));


$data_entrada = mysqli_real_escape_string($conn, $_POST['data_entrada']);
$data_entrada = str_replace("/", "-", $data_entrada);
$data_entrada = date('Y/m/d', strtotime($data_entrada));

$hora_entrada = mysqli_real_escape_string($conn, $_POST['hora_entrada']);
$hora_entrada = str_replace("/", ":", $hora_entrada);
$hora_entrada = date('H:i', strtotime($hora_entrada));

$data_saida = mysqli_real_escape_string($conn, $_POST['data_saida']);
$data_saida = str_replace("/", "-", $data_saida);
$data_saida = date('Y/m/d', strtotime($data_saida));

$hora_saida = mysqli_real_escape_string($conn, $_POST['hora_saida']);
$hora_saida = str_replace("/", ":", $hora_saida);
$hora_saida = Date('H:i', strtotime($hora_saida));


$valor = mysqli_real_escape_string($conn, $_POST['valor']);
$valor = str_replace(",", ".", str_replace(".", "", $_POST['valor']));
    


$altera_estada = "INSERT INTO estadas (nome_funcionario, placa_veiculo, endereco_estacionamento, data_entrada, hora_entrada, data_saida, hora_saida, valor) 
VALUES ('$nome_funcionario', '$placa_veiculo', '$endereco_estacionamento', '$data_entrada', '$hora_entrada', '$data_saida', '$hora_saida', '$valor')";
$resposta = mysqli_query($conn, $altera_estada);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>ESTADA CADASTRADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: estada.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>NÃO FOI POSSÍVEL CADASTRAR A ESTADA!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: estada.php');
    
}


?>
