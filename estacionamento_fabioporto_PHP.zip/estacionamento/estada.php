<?php
session_start();
include_once('static/cabecalho.php');

include('config/conexao.php');
include_once("config/seguranca.php");
seguranca_adm();
$consulta = "SELECT * FROM estadas ";
$resultado = mysqli_query($conn, $consulta);

if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
  $page_no = $_GET['page_no'];
} else {
  $page_no = 1;
}

$total_records_per_page = 10;

$offset = ($page_no - 1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";

$result_count = mysqli_query(
  $conn,
  "SELECT COUNT(*) As total_records FROM `estadas`"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
?>

<style>
  .table__wrapper {
    overflow-x: auto;
  }
</style>

<?php include_once('static/nav.php'); ?>

<section class="section has-background-link-light">
  <div class="container" class="modal fade" id="cadEstada" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <?php
    if (isset($_SESSION['error'])) {
      echo $_SESSION['error'];
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
      echo $_SESSION['success'];
      unset($_SESSION['success']);
    }
    ?>
    <div class="box" style="width: 1048px; max-width: 100%">
      <article class="panel is-info">
        <p class="panel-heading">Cadastro de Estada</p>
        <div class="box">
          <form method="POST" action="processa_cadastro_estadas.php" enctype="multipart/form-data" id="form_contato">


            <label class="label">Funcionarios</label>
            <div class="field is-horizontal">
              <div class="field">
                <label class="label">Nome do Funcionario</label>
                <div class="control">
                  <div class="select">
                    <select class="input" type="nome_funcionario" name="nome_funcionario" id="nome_funcionario">
                      <option>Selecione...</option>
                      <?php
                      $resultado = mysqli_query(
                        $conn,
                        "SELECT nome FROM funcionarios"
                      );
                      while ($linha = mysqli_fetch_array($resultado)) { ?>
                        <option value="<?php echo $linha['nome'] ?>">
                          <?php echo $linha['nome'] ?></option>
                      <?php } ?>
                    </select>

                  </div>

                </div>
              </div>
            </div>
            <hr />
            <label class="label">Veículos</label>
            <div class="field is-horizontal">
              <div class="field">
                <label class="label">Placa do veiculo</label>
                <div class="control">
                  <div class="select">
                    <select class="input" type="placa_veiculo" name="placa_veiculo" required id="placa_veiculo">
                      <option>Selecione...</option>
                      <?php
                      $resultado = mysqli_query(
                        $conn,
                        "SELECT placa FROM veiculos"
                      );
                      while ($linha = mysqli_fetch_array($resultado)) { ?>
                        <option value="<?php echo $linha['placa'] ?>">
                          <?php echo $linha['placa'] ?></option>
                      <?php } ?>
                    </select>
                  </div>

                </div>
              </div>
            </div>
            <hr />
            <label class="label">Estacionamentos</label>
            <div class="field is-horizontal">
              <div class="field">
                <label class="label">Endereço do estacionamento</label>
                <div class="control">
                  <div class="select">
                    <select class="input" type="endereco_estacionamento" name="endereco_estacionamento" required
                      id="endereco_estacionamento">
                      <option>Selecione...</option>
                      <?php
                      $resultado = mysqli_query(
                        $conn,
                        "SELECT endereco FROM estacionamentos"
                      );
                      while ($linha = mysqli_fetch_array($resultado)) { ?>
                        <option value="<?php echo $linha['endereco'] ?>">
                          <?php echo $linha['endereco'] ?></option>
                      <?php } ?>
                    </select>
                  </div>

                </div>
              </div>
            </div>

            <hr />

            <div class="field is-horizontal">
              <div class="field-group">
                <p class="panel-heading">Entrada</p>
                <div class="field">
                  <label class="label">Data de entrada</label>
                  <div class="control">
                    <input class="input" type="data_entrada" name="data_entrada" id="data_entrada" required
                      placeholder="" />
                  </div>

                </div>

                <div class="field">
                  <label class="label">Hora de entrada</label>
                  <div class="control">
                    <input class="input" type="hora_entrada" name="hora_entrada" id="hora_entrada" required
                      placeholder="" />
                  </div>

                </div>

                <p class="panel-heading">Saída</p>
                <div class="field">
                  <label class="label">Data de saída</label>
                  <div class="control">
                    <input class="input" type="data_saida" name="data_saida" id="data_saida" required placeholder="" />

                  </div>

                </div>

                <div class="field">
                  <label class="label">Hora de saída</label>
                  <div class="control">
                    <input class="input" type="hora_saida" name="hora_saida" id="hora_saida" required placeholder="" />

                  </div>

                </div>
              </div>
            </div>

            <hr />
            <div class="field is-horizontal">
              <div class="field">
                <label class="label">Valor</label>
                <div class="control">
                  <input class="input" type="valor" name="valor" id="valor" required placeholder="0,00" />

                </div>

              </div>
            </div>

            <hr />

            <div class="field is-grouped">
              <div class="control">
                <button type="submit" class="button is-link is-light">Adicionar</button>
              </div>
              <div class="control">
                <button type="reset" class="button is-link is-light">Limpar</button>
              </div>
            </div>

          </form>
        </div>
        <hr />
        <article class="panel is-info">
          <p class="panel-heading">Listagen de estadas</p>
          <div class="box">

            <div class="table__wrapper">

              <div class="control is-expanded">
                <label class="label p-2 mt-2">pesquisa: </label>
                <input class="input" type="text" name="pesquisa_estada" id="pesquisa_estada" value="" placeholder=""
                  required autofocus>

              </div>

              <br>

              <table class="table is-table is-bordered is-striped is-narrow is-hoverable is-fullwidth resultado_estada">

                <thead>
                  <tr class="bg-dark text text-white">
                    <th scope="col">ID</th>
                    <th scope="col">Nome de funcionario</th>
                    <th scope="col">Placa de veiculo</th>
                    <th scope="col">Endereço de estacionamento</th>
                    <th scope="col">Data de entrada</th>
                    <th scope="col">Hora de entrada</th>
                    <th scope="col">Data de saida</th>
                    <th scope="col">Hora de entrada</th>
                    <th scope="col">valor</th>
                    <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT * FROM `estadas` LIMIT $offset, $total_records_per_page"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) {
                    $id_estada = $linha['id_estada'];
                    $nome_funcionario = $linha['nome_funcionario'];
                    $placa_veiculo = $linha['placa_veiculo'];
                    $endereco_estacionamento = $linha['endereco_estacionamento'];
                    $data_entrada = $linha['data_entrada'];
                    $data_entrada = date('d/m/Y', strtotime($data_entrada));
                    $hora_entrada = $linha['hora_entrada'];
                    $data_saida = $linha['data_saida'];
                    $data_saida = date('d/m/Y', strtotime($data_saida));
                    $hora_saida = $linha['hora_saida'];
                    $valor = $linha['valor'];
                    $valor = str_replace(",", ".", str_replace(".", "", $linha['valor']));
                    ?>
                    <td>
                      <?= $linha['id_estada'] ?>
                    </td>
                    <td>
                      <?= $linha['nome_funcionario'] ?>
                    </td>
                    <td>
                      <?= $linha['placa_veiculo'] ?>
                    </td>
                    <td>
                      <?= $linha['endereco_estacionamento'] ?>
                    </td>
                    <td>
                      <?= $linha['data_entrada'] ?>
                    </td>
                    <td>
                      <?= $linha['hora_entrada'] ?>
                    </td>
                    <td>
                      <?= $linha['data_saida'] ?>
                    </td>
                    <td>
                      <?= $linha['hora_saida'] ?>
                    </td>
                    <td>
                      <?= $linha['valor'] ?>
                    </td>

                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#visualizarEstada" data-whatever="<?php echo $linha['id_estada']; ?>"
                        data-whatevernome_funcionario="<?php echo $linha['nome_funcionario']; ?>"
                        data-whateverplaca_veiculo="<?php echo $linha['placa_veiculo']; ?>"
                        data-whateverendereco_estacionamento="<?php echo $linha['endereco_estacionamento']; ?>"
                        data-whateverdata_entrada="<?php echo $data_entrada; ?>"
                        data-whateverhora_entrada="<?php echo $linha['hora_entrada']; ?>"
                        data-whateverdata_saida="<?php echo $data_saida; ?>"
                        data-whateverhora_saida="<?php echo $linha['hora_saida']; ?>"
                        data-whatevervalor="<?php echo $linha['valor']; ?>">

                        <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Visualizar"></i>
                      </a>
                    </td>

                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#editarEstada" data-whatever="<?php echo $linha['id_estada']; ?>"
                        data-whatevernome_funcionario="<?php echo $linha['nome_funcionario']; ?>"
                        data-whateverplaca_veiculo="<?php echo $linha['placa_veiculo']; ?>"
                        data-whateverendereco_estacionamento="<?php echo $linha['endereco_estacionamento']; ?>"
                        data-whateverdata_entrada="<?php echo $linha['data_entrada']; ?>"
                        data-whateverhora_entrada="<?php echo $linha['hora_entrada']; ?>"
                        data-whateverdata_saida="<?php echo $linha['data_saida']; ?>"
                        data-whateverhora_saida="<?php echo $linha['hora_saida']; ?>"
                        data-whatevervalor="<?php echo $linha['valor']; ?>">

                        <i class="far fa-edit text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Editar"></i></a>
                      <div class="modal">
                    </td>
                    <td class="text text-center">
                      <a href="processa_excluir_estadas.php?id_estada=<?php echo $linha['id_estada']; ?>"
                        onClick="return confirm('Deseja realmente deletar o veícluo? <?php echo $linha['estada']; ?>')">
                        <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Excluir"></i></a>
                    </td>
                    </tr>
                  </tbody>
                  <?php

                  }
                  mysqli_close($conn);

                  ?>
              </table>

              <strong>Página
                <?php echo $page_no . " de " . $total_no_of_pages; ?>
              </strong>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                  <?php if ($page_no > 1) {
                    echo "<li><a class='pagination-link' href='?page_no=1'> Primeira Página</a></li>";
                  } ?>

                  <li <?php if ($page_no <= 1) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-previous" <?php if ($page_no > 1) {
                      echo "href='?page_no=$previous_page'";
                    } ?>>Anterior</a>
                  </li>


                  <?php if ($total_no_of_pages <= 15) {
                    for ($counter = 1; $counter <= $total_no_of_pages; $counter++) {

                      if ($counter == $page_no) {
                        echo "<li class='active'><a class='pagination-link is-current'>$counter</a></li>";
                      } else {
                        echo "<li><a class='pagination-link' href='?page_no=$counter'>$counter</a></li>";
                      }
                    }
                  } ?>

                  <li <?php if ($page_no >= $total_no_of_pages) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-next" <?php if ($page_no < $total_no_of_pages) {
                      echo "href='?page_no=$next_page'";
                    } ?>>Próximo</a>
                  </li>

                  <?php if ($page_no < $total_no_of_pages) {
                    echo "<li><a class='pagination-link' href='?page_no=$total_no_of_pages'>Último &rsaquo;&rsaquo;</a></li>";
                  } ?>
                </ul>

              </nav>
              <br>
            </div>
          </div>

        </article>
      </article>
    </div>
  </div>
</section>
</div>


<!-- -----------------------------------MODAL VISUALIZAR ESTADA----------------------------------------------------------------->

<div class="modal fade" id="visualizarEstada" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <article class="modal-dialog" role="document">
    <div class="modal-background"></div>
    <div class="modal-card" style="width: 1048px; max-width: 100%">
      <header class="modal-card-head">
        <p class="modal-card-title">Visualizar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">
        <label class="label">Funcionarios</label>
        <div class="field is-horizontal">
          <div class="field">
            <label for="recipient-nome_funcionario" class="label">Nome do Funcionario</label>
            <div class="control">
              <div class="select">
                <select class="input" type="nome_funcionario" id="recipient-nome_funcionario" name="nome_funcionario"
                  id="nome_funcionario">
                  <option>Selecione...</option>
                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT nome_funcionario from estadas INNER JOIN funcionarios ON estadas.nome_funcionario = funcionarios.nome INNER JOIN veiculos ON estadas.placa_veiculo = veiculos.placa INNER JOIN estacionamentos ON estadas.endereco_estacionamento = estacionamentos.endereco"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) { ?>
                    <option value="<?php echo $linha['nome_funcionario'] ?>">
                      <?php echo $linha['nome_funcionario'] ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <label class="label">Veículos</label>
        <div class="field is-horizontal">
          <div class="field">
            <label for="recipient-placa_veiculo" class="label">Placa do veiculo</label>
            <div class="control">
              <div class="select">
                <select class="input" type="placa_veiculo" id="recipient-placa_veiculo" name="placa_veiculo"
                  id="placa_veiculo" disabled>
                  <option>Selecione...</option>
                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT placa FROM veiculos"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) { ?>
                    <option value="<?php echo $linha['id_veiculo'] ?>">
                      <?php echo $linha['placa'] ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <label class="label">Estacionamentos</label>
        <div class="field is-horizontal">
          <div class="field">
            <label for="recipient-endereco_estacionamento" class="label">Endereço do estacionamento</label>
            <div class="control">
              <div class="select">
                <select>
                  <option class="input" type="endereco_estacionamento" id="recipient-endereco_estacionamento"
                    name="endereco_estacionamento" id="endereco_estacionamento" disabled>Selecione...</option>
                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT endereco FROM estacionamentos"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) { ?>
                    <option value="<?php echo $linha['id_estacionamento'] ?>">
                      <?php echo $linha['endereco'] ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div class="field is-horizontal">
          <div class="field-group">
            <p class="panel-heading">Entrada</p>
            <div class="field">
              <label for="recipient-data_entrada" class="label">Data de entrada</label>
              <div class="control">
                <input class="input" type="data_entrada" id="recipient-data_entrada" name="data_entrada"
                  id="data_entrada" required placeholder="" disabled />
              </div>

            </div>

            <div class="field">
              <label for="recipient-hora_entrada" class="label">Hora de entrada</label>
              <div class="control">
                <input class="input" type="hora_entrada" id="recipient-hora_entrada" name="hora_entrada"
                  id="hora_entrada" required placeholder="" disabled />
              </div>

            </div>

            <p class="panel-heading">Saída</p>
            <div class="field">
              <label for="recipient-data_saida" class="label">Data de saída</label>
              <div class="control">
                <input class="input" type="data_saida" id="recipient-data_saida" name="data_saida" id="data_saida"
                  required placeholder="" disabled />

              </div>

            </div>

            <div class="field">
              <label for="recipient-hora_saida" class="label">Hora de saída</label>
              <div class="control">
                <input class="input" type="hora_saida" id="recipient-hora_saida" name="hora_saida" id="hora_saida"
                  required placeholder="" disabled />

              </div>

            </div>
          </div>
        </div>

        <hr />
        <div class="field is-horizontal">
          <div class="field">
            <label for="recipient-valor" class="label">Valor</label>
            <div class="control">
              <input class="input" type="valor" id="recipient-valor" name="valor" id="valor" required placeholder="0,00"
                disabled />

            </div>

          </div>
        </div>
        <hr />
        <input type="hidden" name="id" class="form-control" id="id">
      </section>


      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
      </footer>
    </div>
  </article>
</div>



<div class="modal fade" id="editarEstada" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">Editar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">

        <form method="POST" action="processa_edit_estadas.php" enctype="multipart/form-data" id="form_contato">


          <label class="label">Funcionarios</label>
          <div class="field is-horizontal">
            <div class="field">
              <label for="recipient-nome_funcionario" class="label">Nome do Funcionario</label>
              <div class="control">
                <div class="select">
                  <select class="input" type="nome_funcionario" id="recipient-nome_funcionario" name="nome_funcionario"
                    id="nome_funcionario">
                    <option>Selecione...</option>
                    <?php
                    $resultado = mysqli_query(
                      $conn,
                      "SELECT funcionarios.nome FROM funcionarios INNER JOIN estadas ON estadas.id_estada = funcionarios.id_funcionario"
                    );
                    while ($linha = mysqli_fetch_array($resultado)) { ?>
                      <option value="<?php echo $linha['id_funcionario'] ?>">
                        <?php echo $linha['nome'] ?></option>
                    <?php } ?>
                  </select>
                </div>

              </div>
            </div>
          </div>
          <hr />
          <label class="label">Veículos</label>
          <div class="field is-horizontal">
            <div class="field">
              <label for="recipient-nome_funcionario" class="label">Placa do veiculo</label>
              <div class="control">
                <div class="select">
                  <select class="input" type="placa_veiculo" name="nome_funcionario" id="nome_funcionario">
                    <option>Selecione...</option>
                    <?php
                    $resultado = mysqli_query(
                      $conn,
                      "SELECT placa FROM veiculos INNER JOIN estadas ON estadas.id_estada = veiculos.id_veiculo"
                    );
                    while ($linha = mysqli_fetch_array($resultado)) { ?>
                      <option value="<?php echo $linha['id_veiculo'] ?>">
                        <?php echo $linha['placa'] ?></option>
                    <?php } ?>
                  </select>
                </div>

              </div>
            </div>
          </div>
          <hr />
          <label class="label">Estacionamentos</label>
          <div class="field is-horizontal">
            <div class="field">
              <label for="recipient-endereco_estacionamento" class="label">Endereço do estacionamento</label>
              <div class="control">
                <div class="select">
                  <select class="input" type="endereco_estacionamento" name="endereco_estacionamento"
                    id="endereco_estacionamento">
                    <option>Selecione...</option>
                    <?php
                    $resultado = mysqli_query(
                      $conn,
                      "SELECT endereco FROM estacionamentos INNER JOIN estadas ON estadas.id_estada = estacionamentos.id_estacionamento"
                    );
                    while ($linha = mysqli_fetch_array($resultado)) { ?>
                      <option value="<?php echo $linha['id_estacionamento'] ?>">
                        <?php echo $linha['endereco'] ?></option>
                    <?php } ?>
                  </select>
                </div>

              </div>
            </div>
          </div>

          <hr />

          <div class="field is-horizontal">
            <div class="field-group">
              <p class="panel-heading">Entrada</p>
              <div class="field">
                <label for="recipient-data_entrada" class="label">Data de entrada</label>
                <div class="control">
                  <input class="input" type="data_entrada" id="recipient-data_entrada" name="data_entrada"
                    id="data_entrada" required placeholder="" />
                </div>

              </div>

              <div class="field">
                <label for="recipient-hora_entrada" class="label">Hora de entrada</label>
                <div class="control">
                  <input class="input" type="hora_entrada" id="recipient-hora_entrada" name="hora_entrada"
                    id="hora_entrada" required placeholder="" />
                </div>

              </div>

              <p class="panel-heading">Saída</p>
              <div class="field">
                <label for="recipient-data_saida" class="label">Data de saída</label>
                <div class="control">
                  <input class="input" type="data_saida" id="recipient-data_saida" name="data_saida" id="data_saida"
                    required placeholder="" />

                </div>

              </div>

              <div class="field">
                <label for="recipient-hora_saida" class="label">Hora de saída</label>
                <div class="control">
                  <input class="input" type="hora_saida" id="recipient-hora_saida" name="hora_saida" id="hora_saida"
                    required placeholder="" />

                </div>

              </div>
            </div>
          </div>

          <hr />
          <div class="field is-horizontal">
            <div class="field">
              <label for="recipient-valor" class="label">Valor</label>
              <div class="control">
                <input class="input" type="valor" id="recipient-valor" name="valor" id="valor" required
                  placeholder="0,00" />

              </div>

            </div>
          </div>

          <hr />

          <input type="hidden" name="id" class="form-control" id="id">
      </section>
      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
        <button type="submit" class="button">Salvar Alterações</button>
        <button type="reset" class="button">Limpar</button>
      </footer>
      </form>
    </div>
  </div>

</div>


<?php include_once('static/rodape.php'); ?>


<script>
  $(function () {
    $("#form_contato").validate();
  });
</script>

<!-- -----------------------------------SCRIPT MODAL EDITAR ESTADA----------------------------------------------------------------->
<script type="text/javascript">
  $('#editarEstada').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientnome_funcionario = button.data('whatevernome_funcionario')
    var recipientplaca_veiculo = button.data('whateverplaca_veiculo')
    var recipientendereco_estacionamento = button.data('whateverendereco_estacionamento')
    var recipientdata_entrada = button.data('whateverdata_entrada')
    var recipienthora_entrada = button.data('whateverhora_entrada')
    var recipientdata_saida = button.data('whateverdata_saida')
    var recipienthora_saida = button.data('whateverhora_saida')
    var recipientvalor = button.data('whatevervalor')

    var modal = $(this)
    modal.find('.modal-title').text('EDITAR ESTADA CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-nome_funcionario').val(recipientnome_funcionario)
    modal.find('#recipient-placa_veiculo').val(recipientplaca_veiculo)
    modal.find('#recipient-endereco_estacionamento').val(recipientendereco_estacionamento)
    modal.find('#recipient-data_entrada').val(recipientdata_entrada)
    modal.find('#recipient-hora_entrada').val(recipienthora_entrada)
    modal.find('#recipient-data_saida').val(recipientdata_saida)
    modal.find('#recipient-hora_saida').val(recipienthora_saida)
    modal.find('#recipient-valor').val(recipientvalor)

  })
</script>

<!-- -----------------------------------SCRIPT MODAL VISUALIZAR ESTADA----------------------------------------------------------------->
<script type="text/javascript">
  $('#visualizarEstada').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientnome_funcionario = button.data('whatevernome_funcionario')
    var recipientplaca_veiculo = button.data('whateverplaca_veiculo')
    var recipientendereco_estacionamento = button.data('whateverendereco_estacionamento')
    var recipientdata_entrada = button.data('whateverdata_entrada')
    var recipienthora_entrada = button.data('whateverhora_entrada')
    var recipientdata_saida = button.data('whateverdata_saida')
    var recipienthora_saida = button.data('whateverhora_saida')
    var recipientvalor = button.data('whatevervalor')

    var modal = $(this)
    modal.find('.modal-title').text('VISUALIZAR ESTADA CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-nome_funcionario').val(recipientnome_funcionario)
    modal.find('#recipient-placa_veiculo').val(recipientplaca_veiculo)
    modal.find('#recipient-endereco_estacionamento').val(recipientendereco_estacionamento)
    modal.find('#recipient-data_entrada').val(recipientdata_entrada)
    modal.find('#recipient-hora_entrada').val(recipienthora_entrada)
    modal.find('#recipient-data_saida').val(recipientdata_saida)
    modal.find('#recipient-hora_saida').val(recipienthora_saida)
    modal.find('#recipient-valor').val(recipientvalor)
  })
</script>


<script>
  $(document).ready(function () {
    $(function () {
      //Pesquisar  página
      $("#pesquisa_estada").keyup(function () {

        var pesquisa_estada = $(this).val();

        //Verificar se  digitado
        if (pesquisa_estada != null) {
          var dados = {
            palavra: pesquisa_estada
          }
          $.post('busca_estada.php', dados, function (retorna) {
            //Mostra  resultado obtidos
            $(".resultado_estada").html(retorna);
          });
        } else {
          $(".resultado_estada").html('');
        }
      });
    });

  });
</script>