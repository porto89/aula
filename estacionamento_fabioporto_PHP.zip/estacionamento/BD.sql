-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31-Jan-2023 às 12:50
-- Versão do servidor: 10.4.25-MariaDB
-- versão do PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `estacionar`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `nascimento` date DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `cpf_cnjp` varchar(20) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `complemento` varchar(200) DEFAULT NULL,
  `rua` varchar(300) DEFAULT NULL,
  `numero` varchar(20) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(120) NOT NULL,
  `estado` varchar(120) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `residencial` varchar(20) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `recado` varchar(20) NOT NULL,
  `comercial` varchar(20) NOT NULL,
  `pagamento_dia` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nome`, `nascimento`, `email`, `cpf_cnjp`, `rg`, `cep`, `complemento`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `telefone`, `residencial`, `celular`, `recado`, `comercial`, `pagamento_dia`) VALUES
(1, 'Fabio Porto', '1989-01-01', 'tiwebcode@gmail.com', '111.111.111-11', '12345678910', '97110540', 'casa', '...', '340', '...', '...', '...', '(55) 55555-5555', '(66) 66666-6666', '(66) 66666-6666', '(55) 55555-5555', '(44) 44444-4444', '2023-12-12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `estacionamentos`
--

CREATE TABLE `estacionamentos` (
  `id_estacionamento` int(11) NOT NULL,
  `endereco` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `estacionamentos`
--

INSERT INTO `estacionamentos` (`id_estacionamento`, `endereco`) VALUES
(1, 'Prédio C sala 102');

-- --------------------------------------------------------

--
-- Estrutura da tabela `estadas`
--

CREATE TABLE `estadas` (
  `id_estada` int(11) NOT NULL,
  `nome_funcionario` varchar(150) NOT NULL,
  `placa_veiculo` varchar(10) NOT NULL,
  `endereco_estacionamento` varchar(180) NOT NULL,
  `data_entrada` date DEFAULT NULL,
  `hora_entrada` time DEFAULT NULL,
  `data_saida` date DEFAULT NULL,
  `hora_saida` time DEFAULT NULL,
  `valor` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `estadas`
--

INSERT INTO `estadas` (`id_estada`, `nome_funcionario`, `placa_veiculo`, `endereco_estacionamento`, `data_entrada`, `hora_entrada`, `data_saida`, `hora_saida`, `valor`) VALUES
(1, 'Fabio Porto', 'fbi-2023', 'prédio c sala 102', '2023-11-11', '10:23:00', '2023-02-22', '10:23:00', 500);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `id_funcionario` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `nascimento` date DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `cpf_cnjp` varchar(20) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `complemento` varchar(200) DEFAULT NULL,
  `rua` varchar(300) DEFAULT NULL,
  `numero` varchar(20) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(120) NOT NULL,
  `estado` varchar(120) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `residencial` varchar(20) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `recado` varchar(20) NOT NULL,
  `comercial` varchar(20) NOT NULL,
  `matricula` varchar(20) NOT NULL,
  `data_admissao` date DEFAULT NULL,
  `turno` varchar(20) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`id_funcionario`, `nome`, `nascimento`, `email`, `cpf_cnjp`, `rg`, `cep`, `complemento`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `telefone`, `residencial`, `celular`, `recado`, `comercial`, `matricula`, `data_admissao`, `turno`, `foto`) VALUES
(1, 'Fabio Porto', '1989-01-01', 'tiwebcode@gmail.com', '111.111.111-11', '46546745465', '97110540', 'casa', '...', '340', '...', '...', '...', '(55) 55555-5555', '(66) 66666-6666', '(66) 66666-6666', '(55) 55555-5555', '(44) 44444-4444', '342343', '2023-12-10', 'Noite', 'static/avatar_foto/fabio porto.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `senha` varchar(300) NOT NULL,
  `token` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `usuario`, `senha`, `token`) VALUES
(1, 'Administrador do sistema', 'admin', '202cb962ac59075b964b07152d234b70', 'e0dd669bdfe0821b8083fe92b0689426'),
(5, 'Fabio Porto', 'fabio', '202cb962ac59075b964b07152d234b70', '0710985248ec0d29fb50b7be78d9fac1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `veiculos`
--

CREATE TABLE `veiculos` (
  `id_veiculo` int(11) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `placa` varchar(10) DEFAULT NULL,
  `ano` varchar(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `veiculos`
--

INSERT INTO `veiculos` (`id_veiculo`, `modelo`, `cor`, `placa`, `ano`) VALUES
(1, 'kA', 'Azul', 'FBI-2023', '2023');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices para tabela `estacionamentos`
--
ALTER TABLE `estacionamentos`
  ADD PRIMARY KEY (`id_estacionamento`);

--
-- Índices para tabela `estadas`
--
ALTER TABLE `estadas`
  ADD PRIMARY KEY (`id_estada`),
  ADD KEY `fk_funcionario_1` (`nome_funcionario`),
  ADD KEY `fk_veiculo_1` (`placa_veiculo`),
  ADD KEY `fk_estacionamento_1` (`endereco_estacionamento`);

--
-- Índices para tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`id_funcionario`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `veiculos`
--
ALTER TABLE `veiculos`
  ADD PRIMARY KEY (`id_veiculo`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `estacionamentos`
--
ALTER TABLE `estacionamentos`
  MODIFY `id_estacionamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `estadas`
--
ALTER TABLE `estadas`
  MODIFY `id_estada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `id_funcionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `veiculos`
--
ALTER TABLE `veiculos`
  MODIFY `id_veiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
