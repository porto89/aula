<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();

$nome = mysqli_real_escape_string($conn, ucwords(strtolower($_POST['nome'])));

$nascimento = mysqli_real_escape_string($conn, $_POST['nascimento']);
$nascimento = str_replace("/", "-", $nascimento);
$nascimento = date('Y-m-d', strtotime($nascimento));

$email = mysqli_real_escape_string($conn, strtolower($_POST['email']));


$cpf_cnjp = mysqli_real_escape_string($conn, $_POST['cpf_cnjp']);
$rg = mysqli_real_escape_string($conn, $_POST['rg']);
$cep = mysqli_real_escape_string($conn, $_POST['cep']);
$complemento = mysqli_real_escape_string($conn, $_POST['complemento']);
$rua = mysqli_real_escape_string($conn, $_POST['rua']);
$numero = mysqli_real_escape_string($conn, $_POST['numero']);
$bairro = mysqli_real_escape_string($conn, $_POST['bairro']);
$cidade = mysqli_real_escape_string($conn, $_POST['cidade']);
$estado = mysqli_real_escape_string($conn, $_POST['estado']);
$telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
$residencial = mysqli_real_escape_string($conn, $_POST['residencial']);
$celular = mysqli_real_escape_string($conn, $_POST['celular']);
$recado = mysqli_real_escape_string($conn, $_POST['recado']);
$comercial = mysqli_real_escape_string($conn, $_POST['comercial']);

$pagamento_dia = mysqli_real_escape_string($conn, $_POST['pagamento_dia']);
$pagamento_dia = str_replace("/", "-", $pagamento_dia);
$pagamento_dia = date('Y-m-d', strtotime($pagamento_dia));

$altera_cliente = "INSERT INTO clientes (nome, nascimento, email, cpf_cnjp, rg, cep, complemento, rua, numero, bairro, cidade, estado, telefone, residencial, celular, recado, comercial, pagamento_dia) 
VALUES ('$nome', '$nascimento', '$email', '$cpf_cnjp', '$rg', '$cep', '$complemento', '$rua', '$numero', '$bairro', '$cidade', '$estado', '$telefone', '$residencial', '$celular', '$recado', '$comercial', '$pagamento_dia')";
$resposta = mysqli_query($conn, $altera_cliente);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>CLIENTE CADASTRADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: cliente.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>NÃO FOI POSSÍVEL CADASTRAR O CLIENTE!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: cliente.php');
    
}


?>
