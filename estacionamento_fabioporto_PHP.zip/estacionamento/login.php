<?php
session_start();
include('config/conexao.php');
?>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Inicio</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css"
    />
    <link rel="stylesheet" href="/estacionamento/static/css/field_group.css" />
    <link rel="stylesheet" href="/estacionamento/static/css/menubc.css" />

    <script src="/estacionamento/static/js/calendario.js"></script>

  </head>
    
    <style>
      .bloco {
        border: 1px solid lightgray;
        padding: 20px;
        margin: 10px;
      }

      ul li {
        list-style-position: inside;
        list-style-image: url("static/img/item.png");
      }

      li a {
        text-decoration: none;
      }
    </style>

    <section class="hero is-info is-fullheight">
      <div class="hero-body">
        <div class="container">
          <div class="columns is-centered">
            <div class="column is-5-tablet is-4-desktop is-3-widescreen">
              <form  method="POST" action="valida.php" class="box">
                <div class="field has-text-centered">
                  <img
                    src="static/img/logo.png"
                    alt="Bulma: a modern CSS framework based on Flexbox"
                    width="112"
                    height="28"
                  />
                </div>
                <div class="field">
                  <label for="" class="label" name="usuario">Usuário</label>
                  <div class="control has-icons-left">
                    <input
                      name="usuario"
                      
                      placeholder=""
                      class="input"
                      required
                    />
                    <span class="icon is-small is-left">
                      <i class="fa fa-envelope"></i>
                    </span>
                  </div>
                </div>
                <div class="field">
                  <label for="" class="label" name="senha">Senha</label>
                  <div class="control has-icons-left">
                    <input
                    name="senha"
                      type="password"
                      placeholder="*******"
                      class="input"
                      required
                    />
                    <span class="icon is-small is-left">
                      <i class="fa fa-lock"></i>
                    </span>
                  </div>
                </div>
                <div class="field">
                  <button class="button is-info" type="submit">Entrar</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

<script>
 // SCRIPT DE VALIDAÇÃO DO PROPRIO
  (function() {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
      .forEach(function(form) {
        form.addEventListener('submit', function(event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
  })()
</script>