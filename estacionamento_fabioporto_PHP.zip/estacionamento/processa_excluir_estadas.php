<?php
session_start();
include_once('assets/cabecalho.php');
include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();


$id_estada = mysqli_real_escape_string($conn, $_GET['id_estada']);

$altera_estada = "DELETE FROM estadas WHERE id_estada='$id_estada'";
$resposta = mysqli_query($conn, $altera_estada);

if ($resposta) {
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-warning'>
      <p>ESTADA EXCLUÍDO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: estada.php');
} else {

    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-warning'>
      <p>NÃO FOI POSSÍVEL EXCLUIR A ESTADA!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: estada.php');

}

?>