<?php
session_start();
//include_once('static/cabecalho.php');
//include_once('static/rodape.php');
include('config/conexao.php');
// include_once("config/seguranca.php");
// seguranca_adm();
$consulta = "SELECT * FROM veiculos ";
$resultado = mysqli_query($conn, $consulta);
?>


<?php
if (isset($_SESSION['error'])) {
  echo $_SESSION['error'];
  unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
  echo $_SESSION['success'];
  unset($_SESSION['success']);
}


$busca = $_POST['palavra'];
$busca = "SELECT * FROM veiculos WHERE placa LIKE '%$busca%'";
$resultado = mysqli_query($conn, $busca);
?>

<table class="table table-bordered table-hover table-sm table-responsive-xl resultado_veiculo">

  <thead>
    <tr class="bg-dark text text-white">
      <th scope="col">ID</th>
      <th scope="col">Modelo</th>
      <th scope="col">Cor</th>
      <th scope="col">Placa</th>
      <th scope="col">Ano</th>
      <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
    </tr>
  </thead>
  <tbody>
    <?php

    while ($linha = mysqli_fetch_assoc($resultado)) {
      $id_veiculo = $linha['id_veiculo'];
      $modelo = $linha['modelo'];
      $cor = $linha['cor'];
      $placa = $linha['placa'];
      $ano = $linha['ano'];
      ?>
      <td>
        <?= $linha['id_veiculo'] ?>
      </td>
      <td>
        <?= $linha['modelo'] ?>
      </td>
      <td>
        <?= $linha['cor'] ?>
      </td>
      <td>
        <?= $linha['placa'] ?>
      </td>
      <td>
        <?= $linha['ano'] ?>
      </td>

      <td class="text text-center">
        <a href="#" data-toggle="modal" 
        data-backdrop="static" 
        data-keyboard="false" 
        data-target="#visualizarVeiculo"
        data-whatever="<?php echo $linha['id_veiculo']; ?>"
        data-whatevermodelo="<?php echo $linha['modelo']; ?>"
        data-whatevercor="<?php echo $linha['cor']; ?>"
        data-whateverplaca="<?php echo $linha['placa']; ?>"
        data-whateverano="<?php echo $linha['ano']; ?>"
        
        >

          <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top" title="Visualizar"></i>
        </a>
      </td>

      <td class="text text-center">
        <a href="#" data-toggle="modal" 
        data-backdrop="static" 
        data-keyboard="false" 
        data-target="#editarVeiculo"
        data-whatever="<?php echo $linha['id_veiculo']; ?>"
        data-whatevermodelo="<?php echo $linha['modelo']; ?>"
        data-whatevercor="<?php echo $linha['cor']; ?>"
        data-whateverplaca="<?php echo $linha['placa']; ?>"
        data-whateverano="<?php echo $linha['ano']; ?>"
        >

          <i class="far fa-edit text text-dark" 
          data-bs-toggle="tooltip" data-bs-placement="top" title="Editar"></i></a>
        <div class="modal">
      </td>
      <td class="text text-center">
        <a href="processa_excluir_veiculos.php?id_veiculo=<?php echo $linha['id_veiculo']; ?>"
          onClick="return confirm('Deseja realmente deletar o veícluo? <?php echo $linha['veiculo']; ?>')">
          <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
            title="Excluir"></i></a>
      </td>
      </tr>
    </tbody>
    <?php

    }
    mysqli_close($conn);

    ?>
</table>