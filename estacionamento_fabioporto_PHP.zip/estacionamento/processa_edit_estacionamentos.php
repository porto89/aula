<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();

$id_estacionamento = mysqli_real_escape_string($conn, $_POST['id']);
$endereco = mysqli_real_escape_string($conn, $_POST['endereco']);

$altera_estacionamento = "UPDATE estacionamentos SET endereco='$endereco' WHERE id_estacionamento='$id_estacionamento'";
$resposta = mysqli_query($conn, $altera_estacionamento);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='message-header'>
      <p>ESTACIONAMENTO EDITADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: estacionamento.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='message-header'>
      <p>NÃO FOI POSSÍVEL EDITAR O ESTACIONAMENTOO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: estacionamento.php');
    
}

?>