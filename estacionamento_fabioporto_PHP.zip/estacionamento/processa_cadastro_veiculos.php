<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();

$id_veiculo = mysqli_real_escape_string($conn, $_POST['id']);
$modelo = mysqli_real_escape_string($conn, $_POST['modelo']);
$cor = mysqli_real_escape_string($conn, $_POST['cor']);
$placa = mysqli_real_escape_string($conn, $_POST['placa']);
$ano = mysqli_real_escape_string($conn, $_POST['ano']);

$altera_veiculo = "INSERT INTO veiculos (modelo, cor, placa, ano) 
VALUES ('$modelo', '$cor', '$placa', '$ano')";
$resposta = mysqli_query($conn, $altera_veiculo);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>VEÍCULO CADASTRADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: veiculo.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-link'>
      <p>NÃO FOI POSSÍVEL CADASTRAR O VEÍCULO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: veiculo.php');
    
}


?>
