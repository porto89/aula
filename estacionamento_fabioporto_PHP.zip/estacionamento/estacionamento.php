<?php
session_start();
include_once('static/cabecalho.php');

include('config/conexao.php');
include_once("config/seguranca.php");
seguranca_adm();
$consulta = "SELECT * FROM estacionamentos ";
$resultado = mysqli_query($conn, $consulta);

if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
  $page_no = $_GET['page_no'];
} else {
  $page_no = 1;
}

$total_records_per_page = 10;

$offset = ($page_no - 1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = "2";

$result_count = mysqli_query(
  $conn,
  "SELECT COUNT(*) As total_records FROM `estacionamentos`"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
?>

<style>
  .table__wrapper {
    overflow-x: auto;
  }
</style>

<?php include_once('static/nav.php'); ?>


<section class="section has-background-link-light">
  <div class="container">
    <?php
    if (isset($_SESSION['error'])) {
      echo $_SESSION['error'];
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
      echo $_SESSION['success'];
      unset($_SESSION['success']);
    }
    ?>
    <div class="box" style="width: 1048px; max-width: 100%">
      <article class="panel is-info">
        <p class="panel-heading">Cadastro de Estacionamento</p>
        <div class="box">
          <form method="POST" action="processa_cadastro_estacionamentos.php" enctype="multipart/form-data"
            id="form_contato">

            <div class="field-group is-horizontal">
              <div class="field">
                <label class="label" id="recipient-endereco" required="required">Endereço</label>
                <div class="control">

                  <input class="input" type="endereco" required name="endereco" id="endereco" id="recipient-endereco" />
                </div>

              </div>
            </div>

            <div class="field is-grouped">
              <div class="control">
                <button type="submit" class="button is-link is-light">Adicionar</button>
              </div>
              <div class="control">
                <button type="reset" class="button is-link is-light">Limpar</button>
              </div>
            </div>
          </form>
        </div>

        <hr />

        <article class="panel is-info">
          <p class="panel-heading">Listagen de Estacionamentos</p>
          <div class="box">

            <div class="table__wrapper">

              <div class="control is-expanded">
                <label class="label p-2 mt-2">Nome do endereco: </label>
                <input class="input" type="text" name="pesquisa_estacionamento" id="pesquisa_estacionamento" value=""
                  placeholder="Nome do endereco" required autofocus>

              </div>

              <br>

              <table
                class="table is-table is-bordered is-striped is-narrow is-hoverable is-fullwidth resultado_estacionamento">

                <thead>
                  <tr class="bg-dark text text-white">
                    <th scope="col">CÓD</th>
                    <th scope="col">ENDEREÇO</th>
                    <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
                  </tr>
                </thead>
                <tbody>



                  <?php
                  $resultado = mysqli_query(
                    $conn,
                    "SELECT * FROM `estacionamentos` LIMIT $offset, $total_records_per_page"
                  );
                  while ($linha = mysqli_fetch_array($resultado)) {
                    $id_estacionamento = $linha['id_estacionamento'];
                    $endereco = $linha['endereco'];

                    ?>
                    <td>
                      <?= $linha['id_estacionamento'] ?>
                    </td>
                    <td>
                      <?= $linha['endereco'] ?>
                    </td>
                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#visualizarEstacionamento" data-whatever="<?php echo $linha['id_estacionamento']; ?>"
                        data-whateverendereco="<?php echo $linha['endereco']; ?>">
                        <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Visualizar"></i>
                      </a>
                    </td>

                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                        data-target="#editarEstacionamento" data-whatever="<?php echo $linha['id_estacionamento']; ?>"
                        data-whateverendereco="<?php echo $endereco; ?>">
                        <i class="far fa-edit text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Editar"></i></a>
                      <div class="modal">
                    </td>
                    <td class="text text-center">
                      <a href="processa_excluir_estacionamentos.php?id_estacionamento=<?php echo $linha['id_estacionamento']; ?>"
                        onClick="return confirm('Deseja realmente deletar o estacionamento? <?php echo $linha['estacionamento']; ?>')">
                        <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Excluir"></i></a>
                    </td>
                    </tr>
                  </tbody>
                  <?php

                  }
                  mysqli_close($conn);

                  ?>
              </table>

              <strong>Página
                <?php echo $page_no . " de " . $total_no_of_pages; ?>
              </strong>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                  <?php if ($page_no > 1) {
                    echo "<li><a class='pagination-link' href='?page_no=1'> Primeira Página</a></li>";
                  } ?>

                  <li <?php if ($page_no <= 1) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-previous" <?php if ($page_no > 1) {
                      echo "href='?page_no=$previous_page'";
                    } ?>>Anterior</a>
                  </li>


                  <?php if ($total_no_of_pages <= 15) {
                    for ($counter = 1; $counter <= $total_no_of_pages; $counter++) {

                      if ($counter == $page_no) {
                        echo "<li class='active'><a class='pagination-link is-current'>$counter</a></li>";
                      } else {
                        echo "<li><a class='pagination-link' href='?page_no=$counter'>$counter</a></li>";
                      }
                    }
                  } ?>

                  <li <?php if ($page_no >= $total_no_of_pages) {
                    echo "class='disabled'";
                  } ?>>
                    <a class="pagination-next" <?php if ($page_no < $total_no_of_pages) {
                      echo "href='?page_no=$next_page'";
                    } ?>>Próximo</a>
                  </li>

                  <?php if ($page_no < $total_no_of_pages) {
                    echo "<li><a class='pagination-link' href='?page_no=$total_no_of_pages'>Último &rsaquo;&rsaquo;</a></li>";
                  } ?>
                </ul>

              </nav>
              <br>
            </div>
          </div>

        </article>
      </article>
    </div>
  </div>
</section>
</div>




<?php include_once('static/rodape.php'); ?>




<!-- -----------------------------------MODAL VISUALIZAR ESTACIONAMENTO----------------------------------------------------------------->


<div class="modal fade" id="visualizarEstacionamento" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">Visualizar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">
        <div class="field-group is-horizontal">
          <div class="field">
            <div class="control">
              <label for="recipient-endereco" class="col-form-label">Endereço</label>
              <input type="text" class="input" id="recipient-endereco" maxlength="50" disabled>
            </div>
          </div>
        </div>
      </section>
      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
      </footer>
    </div>
  </div>
</div>



<div class="modal fade" id="editarEstacionamento" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">Editar</p>
        <button class="delete" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </header>
      <section class="modal-card-body">

        <form method="POST" action="processa_edit_estacionamentos.php" enctype="multipart/form-data" id="form_contato">
          <div class="field-group is-horizontal">
            <div class="field">
              <div class="control">
                <label for="recipient-endereco" class="col-form-label">Endereço</label>
                <input type="text" class="input" id="recipient-endereco" required="required" name="endereco" />
              </div>
            </div>
          </div>
          <input type="hidden" name="id" class="form-control" id="id">
      </section>
      <footer class="modal-card-foot">
        <button type="button" class="button" data-dismiss="modal">Fechar</button>
        <button type="submit" class="button">Salvar Alterações</button>
        <button type="reset" class="button">Limpar</button>
      </footer>
      </form>
    </div>
  </div>
</div>


<script>
  $(function () {
    $("#form_contato").validate();
  });
</script>


<!-- -----------------------------------SCRIPT MODAL EDITAR ESTACIONAMENTO----------------------------------------------------------------->
<script type="text/javascript">
  $('#editarEstacionamento').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget)
    var recipient = button.data('whatever')
    var recipientendereco = button.data('whateverendereco')

    var modal = $(this)
    modal.find('.modal-title').text('EDITAR CLIENTE CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-endereco').val(recipientendereco)


  })
</script>



<!-- -----------------------------------SCRIPT MODAL VISUALIZAR ESTACIONAMENTO----------------------------------------------------------------->
<script type="text/javascript">
  $('#visualizarEstacionamento').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Botão que acionou o modal
    var recipient = button.data('whatever')
    var recipientendereco = button.data('whateverendereco')
    var modal = $(this)
    modal.find('.modal-title').text('VISUALIZAR ESTACIONAMETO CÓDIGO: ' + recipient)
    modal.find('#id').val(recipient)
    modal.find('#recipient-endereco').val(recipientendereco)
  })
</script>




<script>
  $(document).ready(function () {
    $(function () {
      //Pesquisar 
      $("#pesquisa_estacionamento").keyup(function () {

        var pesquisa_estacionamento = $(this).val();

        //Verificar se   digitado
        if (pesquisa_estacionamento != null) {
          var dados = {
            palavra: pesquisa_estacionamento
          }
          $.post('busca_estacionamento.php', dados, function (retorna) {
            //Mostra  resultado obtidos
            $(".resultado_estacionamento").html(retorna);
          });
        } else {
          $(".resultado_estacionamento").html('');
        }
      });
    });

  });
</script>