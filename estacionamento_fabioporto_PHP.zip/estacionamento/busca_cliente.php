<?php
session_start();
//include_once('static/cabecalho.php');
//include_once('static/rodape.php');
include('config/conexao.php');
// include_once("config/seguranca.php");
// seguranca_adm();
$consulta = "SELECT * FROM clientes ";
$resultado = mysqli_query($conn, $consulta);
?>


<?php
if (isset($_SESSION['error'])) {
    echo $_SESSION['error'];
    unset($_SESSION['error']);
}
if (isset($_SESSION['success'])) {
    echo $_SESSION['success'];
    unset($_SESSION['success']);
}


$busca = $_POST['palavra'];
$busca = "SELECT * FROM clientes WHERE nome LIKE '%$busca%'";
$resultado = mysqli_query($conn, $busca);
?>

<table class="table table-bordered table-hover table-sm table-responsive-xl resultado_cliente">

                <thead>
                  <tr class="bg-dark text text-white">
                    <th scope="col">ID</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Data de nascimento</th>
                    <th scope="col">Email</th>
                    <th scope="col">CPF/CNPJ</th>
                    <th scope="col">RG</th>
                    <th scope="col">CEP</th>
                    <th scope="col">Rua</th>
                    <th scope="col">Numero</th>
                    <th scope="col">Complemento</th>
                    <th scope="col">Bairro</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Telefone</th>
                    <th scope="col">Residencial</th>
                    <th scope="col">Celular</th>
                    <th scope="col">Recado</th>
                    <th scope="col">Comercial</th>
                    <th scope="col">Pagamento dia</th>
                    <th scope="col" class="text text-center" colspan="3">AÇÕES</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  
                  while ($linha = mysqli_fetch_assoc($resultado)) {
                    $id_cliente = $linha['id_cliente'];
                    $nome = $linha['nome'];

                    $nascimento = $linha['nascimento'];
                    $nascimento = date('d/m/Y',  strtotime($nascimento));

                    $email = $linha['email'];
                    $cpf_cnjp = $linha['cpf_cnjp'];
                    $rg = $linha['rg'];
                    $cep = $linha['cep'];
                    $rua = $linha['rua'];
                    $numero = $linha['numero'];
                    $complemento = $linha['complemento'];
                    $bairro = $linha['bairro'];
                    $cidade = $linha['cidade'];
                    $estado = $linha['estado'];
                    $telefone = $linha['telefone'];
                    $residencial = $linha['residencial'];
                    $celular = $linha['celular'];
                    $recado = $linha['recado'];
                    $comercial = $linha['comercial'];

                    $pagamento_dia = $linha['pagamento_dia'];
                    $pagamento_dia = date('d/m/Y',  strtotime($pagamento_dia));

                    $endereco = $rua . ", " . $numero . " - " . $bairro . "-" . $cidade . "/" . $estado;

                    ?>
                    <td>
                      <?= $linha['id_cliente'] ?>
                    </td>
                    <td>
                      <?= $linha['nome'] ?>
                    </td>
                    <td>
                      <?= $linha['nascimento'] ?>
                    </td>
                    <td>
                      <?= $linha['email'] ?>
                    </td>
                    <td>
                      <?= $linha['cpf_cnjp'] ?>
                    </td>
                    <td>
                      <?= $linha['rg'] ?>
                    </td>
                    <td>
                      <?= $linha['cep'] ?>
                    </td>
                    <td>
                      <?= $linha['rua'] ?>
                    </td>
                    <td>
                      <?= $linha['numero'] ?>
                    </td>
                    <td>
                      <?= $linha['complemento'] ?>
                    </td>
                    <td>
                      <?= $linha['bairro'] ?>
                    </td>
                    <td>
                      <?= $linha['cidade'] ?>
                    </td>
                    <td>
                      <?= $linha['estado'] ?>
                    </td>
                    <td>
                      <?= $linha['telefone'] ?>
                    </td>
                    <td>
                      <?= $linha['residencial'] ?>
                    </td>
                    <td>
                      <?= $linha['celular'] ?>
                    </td>
                    <td>
                      <?= $linha['recado'] ?>
                    </td>
                    <td>
                      <?= $linha['comercial'] ?>
                    </td>
                    <td>
                      <?= $linha['pagamento_dia'] ?>
                    </td>
                    <td class="text text-center">
                      <a href="#" data-toggle="modal" 
                      data-backdrop="static" 
                      data-keyboard="false"
                        data-target="#visualizarCliente" 
                        data-target="#visualizarCliente" data-whatever="<?php echo $linha['id_cliente']; ?>"
                        data-whatevernome="<?php echo ucwords(strtolower($linha['nome'])); ?>"
                        data-whatevernascimento="<?php echo $nascimento; ?>"
                        data-whateveremail="<?php echo $linha['email']; ?>"
                        data-whatevercpfcnjp="<?php echo $linha['cpf_cnjp']; ?>"
                        data-whateverrg="<?php echo $linha['rg']; ?>" data-whatevercep="<?php echo $linha['cep']; ?>"
                        data-whateverrua="<?php echo ucwords(strtolower($linha['rua'])); ?>"
                        data-whatevernumero="<?php echo $linha['numero']; ?>"
                        data-whatevercomplemento="<?php echo $linha['complemento']; ?>"
                        data-whateverbairro="<?php echo $linha['bairro']; ?>"
                        data-whatevercidade="<?php echo $linha['cidade']; ?>"
                        data-whateverestado="<?php echo $linha['estado']; ?>"
                        data-whatevertelefone="<?php echo $linha['telefone']; ?>"
                        data-whateverresidencial="<?php echo $linha['residencial']; ?>"
                        data-whatevercelular="<?php echo $linha['celular']; ?>"
                        data-whateverrecado="<?php echo $linha['recado']; ?>"
                        data-whatevercomercial="<?php echo $linha['comercial']; ?>"
                        data-whateverpagamento_dia="<?php echo $pagamento_dia; ?>">
                        
                        <i class="far fa-eye text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Visualizar"></i>
                      </a>
                    </td>

                    <td class="text text-center">
                      <a href="#" data-toggle="modal" data-backdrop="static" data-keyboard="false"
                      data-target="#editarCliente" data-whatever="<?php echo $linha['id_cliente']; ?>"
                        data-whatevernome="<?php echo ucwords(strtolower($linha['nome'])); ?>"
                        data-whatevernascimento="<?php echo $nascimento; ?>"
                        data-whateveremail="<?php echo $linha['email']; ?>"
                        data-whatevercpfcnjp="<?php echo $linha['cpf_cnjp']; ?>"
                        data-whateverrg="<?php echo $linha['rg']; ?>" data-whatevercep="<?php echo $linha['cep']; ?>"
                        data-whateverrua="<?php echo ucwords(strtolower($linha['rua'])); ?>"
                        data-whatevernumero="<?php echo $linha['numero']; ?>"
                        data-whatevercomplemento="<?php echo $linha['complemento']; ?>"
                        data-whateverbairro="<?php echo $linha['bairro']; ?>"
                        data-whatevercidade="<?php echo $linha['cidade']; ?>"
                        data-whateverestado="<?php echo $linha['estado']; ?>"
                        data-whatevertelefone="<?php echo $linha['telefone']; ?>"
                        data-whateverresidencial="<?php echo $linha['residencial']; ?>"
                        data-whatevercelular="<?php echo $linha['celular']; ?>"
                        data-whateverrecado="<?php echo $linha['recado']; ?>"
                        data-whatevercomercial="<?php echo $linha['comercial']; ?>"
                        data-whateverpagamento_dia="<?php echo $linha['pagamento_dia']; ?>">

                        <i class="far fa-edit text text-dark" 
                        data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Editar"></i></a>
                      <div class="modal">
                    </td>
                    <td class="text text-center">
                      <a href="processa_excluir_clientes.php?id_cliente=<?php echo $linha['id_cliente']; ?>"
                        onClick="return confirm('Deseja realmente deletar a cliente? <?php echo $linha['cliente']; ?>')">
                        <i class="far fa-trash-alt text text-dark" data-bs-toggle="tooltip" data-bs-placement="top"
                          title="Excluir"></i></a>
                    </td>
                    </tr>
                  </tbody>
                  <?php

                  }
                  mysqli_close($conn);

                  ?>
              </table>

