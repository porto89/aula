<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();


$id_funcionario = mysqli_real_escape_string($conn, $_POST['id']);
$nome = mysqli_real_escape_string($conn, ucwords(strtolower($_POST['nome'])));
$nascimento = mysqli_real_escape_string($conn, $_POST['nascimento']);
$nascimento = str_replace("/", "-", $nascimento);
$nascimento = date('Y-m-d', strtotime($nascimento));

$email = mysqli_real_escape_string($conn, strtolower($_POST['email']));


$cpf_cnjp = mysqli_real_escape_string($conn, $_POST['cpf_cnjp']);
$rg = mysqli_real_escape_string($conn, $_POST['rg']);
$cep = mysqli_real_escape_string($conn, $_POST['cep']);
$complemento = mysqli_real_escape_string($conn, $_POST['complemento']);
$rua = mysqli_real_escape_string($conn, $_POST['rua']);
$numero = mysqli_real_escape_string($conn, $_POST['numero']);
$bairro = mysqli_real_escape_string($conn, $_POST['bairro']);
$cidade = mysqli_real_escape_string($conn, $_POST['cidade']);
$estado = mysqli_real_escape_string($conn, $_POST['estado']);
$telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
$residencial = mysqli_real_escape_string($conn, $_POST['residencial']);
$celular = mysqli_real_escape_string($conn, $_POST['celular']);
$recado = mysqli_real_escape_string($conn, $_POST['recado']);
$comercial = mysqli_real_escape_string($conn, $_POST['comercial']);
$matricula = mysqli_real_escape_string($conn, $_POST['matricula']);

$data_admissao= mysqli_real_escape_string($conn, $_POST['data_admissao']);
$data_admissao = str_replace("/", "-", $data_admissao);
$data_admissao = date('Y-m-d', strtotime($data_admissao));

$turno = mysqli_real_escape_string($conn, $_POST['turno']);

$foto = mysqli_real_escape_string($conn, $_POST['foto']);


$target_dir = "static/avatar_foto/";
$target_file = $target_dir . basename($_FILES["foto"]["name"]);
$imageExt = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$allowd_file_ext = array("jpg", "jpeg", "png");

if (!file_exists($_FILES["foto"]["tmp_name"])) {
  $resMessage = array(
    "status" => "alert-danger",
    "message" => "Select image to upload."
  );
} else if (!in_array($imageExt, $allowd_file_ext)) {
  $resMessage = array(
    "status" => "alert-danger",
    "message" => "Allowed file formats .jpg, .jpeg and .png."
  );
} else if ($_FILES["foto"]["size"] > 2097152) {
  $resMessage = array(
    "status" => "alert-danger",
    "message" => "File is too large. File size should be less than 2 megabytes."
  );
} else if (file_exists($target_file)) {
  $resMessage = array(
    "status" => "alert-danger",
    "message" => "File already exists."
  );
} else {
  if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {

    $resMessage = array(
      "message" => "Image uploaded successfully."
    );

  } else {
    $resMessage = array(
      "status" => "alert-danger",
      "message" => "Image coudn't be uploaded."
    );
  }
}


$altera_funcionario = "UPDATE funcionarios SET nome='$nome', nascimento='$nascimento', email='$email', cpf_cnjp='$cpf_cnjp', rg='$rg', cep='$cep', 
rua='$rua', numero='$numero', complemento='$complemento', bairro='$bairro', cidade='$cidade', estado='$estado', telefone='$telefone', 
residencial='$residencial', celular='$celular', recado='$recado', comercial='$comercial', matricula='$matricula', data_admissao='$data_admissao', turno='$turno', foto='$target_file' WHERE id_funcionario='$id_funcionario'";
$resposta = mysqli_query($conn, $altera_funcionario);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-success'>
      <p>FUNCIONARIO EDITADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: funcionario.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-success'>
      <p>NÃO FOI POSSÍVEL EDITAR O FUNCIONARIO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: funcionario.php');
    
}

?>