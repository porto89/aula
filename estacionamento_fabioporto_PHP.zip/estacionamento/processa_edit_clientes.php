<?php
session_start();

include('config/conexao.php');
//include_once("config/seguranca.php");
//seguranca_adm();

$id_cliente = mysqli_real_escape_string($conn, $_POST['id']);
$nome = mysqli_real_escape_string($conn, ucwords(strtolower($_POST['nome'])));

$nascimento = mysqli_real_escape_string($conn, $_POST['nascimento']);
$nascimento = str_replace("/", "-", $nascimento);
$nascimento = date('Y-m-d', strtotime($nascimento));

$email = mysqli_real_escape_string($conn, strtolower($_POST['email']));
$cpf_cnjp = mysqli_real_escape_string($conn, $_POST['cpf_cnjp']);
$rg = mysqli_real_escape_string($conn, $_POST['rg']);
$cep = mysqli_real_escape_string($conn, $_POST['cep']);
$rua = mysqli_real_escape_string($conn, $_POST['rua']);
$numero = mysqli_real_escape_string($conn, $_POST['numero']);
$complemento = mysqli_real_escape_string($conn, $_POST['complemento']);
$bairro = mysqli_real_escape_string($conn, $_POST['bairro']);
$cidade = mysqli_real_escape_string($conn, $_POST['cidade']);
$estado = mysqli_real_escape_string($conn, $_POST['estado']);
$telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
$residencial = mysqli_real_escape_string($conn, $_POST['residencial']);
$celular = mysqli_real_escape_string($conn, $_POST['celular']);
$recado = mysqli_real_escape_string($conn, $_POST['recado']);
$comercial = mysqli_real_escape_string($conn, $_POST['comercial']);
$pagamento_dia = mysqli_real_escape_string($conn, $_POST['pagamento_dia']);
$pagamento_dia = str_replace("/", "-", $pagamento_dia);
$pagamento_dia = date('Y-m-d', strtotime($pagamento_dia));


$altera_cliente = "UPDATE clientes SET nome='$nome', nascimento='$nascimento', email='$email', cpf_cnjp='$cpf_cnjp', rg='$rg', cep='$cep', 
rua='$rua', numero='$numero', complemento='$complemento', bairro='$bairro', cidade='$cidade', estado='$estado', telefone='$telefone', 
residencial='$residencial', celular='$celular', recado='$recado', comercial='$comercial', pagamento_dia='$pagamento_dia' WHERE id_cliente='$id_cliente'";
$resposta = mysqli_query($conn, $altera_cliente);

if($resposta){
    //$_SESSION['success'] = "<div class='danger' role='alert' id='sumirDiv'><center>Área Restrita - Realize Login</center></div>";
    $_SESSION['success'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-success'>
      <p>ESTACIONAMENTO EDITADO COM SUCESSO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
    header('Location: cliente.php');
}else{
    $_SESSION['error'] = "<div class='alert alert-success alert-dismissible fade show text text-center mb-0' role='alert'>
    <div class='notification is-success'>
      <p>NÃO FOI POSSÍVEL EDITAR O ESTACIONAMENTOO!</p>
      <button class='delete' data-dismiss='alert' aria-label='Close'>
      <span aria-hidden='true'>&times;</span>
      </button>
      
    </div>
  </div>";
     header('Location: cliente.php');
    
}

?>